==============
 aims_ceph
==============

------------------------
AIMS Ceph solution
------------------------

:Author:        Sven Vermeulen <sven.vermeulen@siphos.be>
:Date:          2015-07-02
:Manual section:        8
:Manual group:          AIMS

DESCRIPTION
===========

Ceph distributed storage allows for a highly available object store with support
for a POSIX compliant file system as well as distributed block devices (RBD).

The "container" that AIMS uses is a pool. Every created pool has a number of placement
groups in Ceph (which is automatically handled) which allow for the distribution and
replication of object parts across the various OSDs.

It is possible to combine two specific pools (one for data and one for metadata) into
a file system. This file system can then be mounted on the system using **mount.ceph**.

Object Store Daemons
--------------------

At the base, Ceph uses OSD to store the objects. Multiple OSDs can be available
per system. When created, they (by default) use the ``/var/lib/ceph/osd/`` location
for the mount points, with each mount named ``<cluster>-<id>``. So a Ceph OSD in the
cluster **ceph** and OSD id **0** becomes ``ceph-0``.

In AIMS, OSDs are created using the ``osd`` type with **aims-instance-create**::

  ~# aims instance create -c ceph -t osd "/dev/vda2"

Monitor Daemons
---------------

In order to control the replications, a number of Monitor servers (MON) need to be
available on the cluster. It is recommended to have 2n+1 monitors.

In AIMS, MONs are created using the ``mon`` type with **aims-instance-create**::

  ~# aims instance create -c ceph -t mon mon.0

Metadata Server
---------------

Finally, the last daemon of interest, is the Metadata Server (MDS). This is needed
when a file system is created on the Ceph cluster (only a single file system can be
made!).

In AIMS, MDSs are created using the ``mds`` type with **aims-instance-create**::

  ~# aims instance create -c ceph -t mds mds.0

ADMINISTRATION
==============

Filesystem
----------

To create a file system::

  ~# ceph fs new <name> <metadatapool> <datapool>

To list the existing file system::

  ~# ceph fs ls

To remove a file system, first fail the MDS. Then remove the file system::

  ~# ceph mds set_max_mds 0
  ~# ceph mds fail 0
  ~# ceph fs rm <name>

Pools
-----

Note that the basic pool steps are handled through the AIMS container support.

To create a pool::

  ~# ceph osd pool create <name> <num_pgs>

To list the pools::

  ~# ceph osd lspools

To remove a pool::

  ~# ceph osd delete <name>

AUTHENTICATION
==============

Ceph uses keyrings for the authentication. During the creation of the cluster,
the *client.admin* keyring is created. Access to the keyring provides succesful
authentication towards the cluster.

New keys are created using the **ceph auth get-or-create** command (see AUTHORIZATION).

AUTHORIZATION
=============

To create a client key, use the **ceph auth** command.

The following example creates a client key who has access to a Ceph pool called
"testpool"::

  ~# ceph auth get-or-create client.myuser osd 'allow rwx pool=testpool' mon 'allow r' > client.myuser.keyring

The resulting file *client.myuser.keyring* can then be passed on to the **ceph**
or **rados** commands::

  ~$ rados -n client.myuser --keyring=client.myuser.keyring -p testpool put "/user/myuser/pic1" somepicture.jpg

Note that the end user must have read access to the ``/etc/ceph`` location, but
not to the keyrings and secrets.

AUDITING
========

By default, Ceph will create an audit log file called ``/var/log/ceph/<cluster>.audit.log``.

BACKUP AND RESTORE
==================

A plausible approach for backup/restore is to use snapshots (which can then be
accessed separately to easily perform the backups in the background on a set of
data that is not changed anymore)::

  ~# ceph osd pool mksnap <poolname> <snapshotname>

Removing the snapshot is done using the **rmsnap** subcommand.

CONFIGURATION
=============

The majority of configuration is done through the ``/etc/ceph/<cluster>.conf``
configuration file or the key/value pairs that can be set through the various
**ceph** commands.

For instance, to set pool parameters (reading is done using **get**)::

  ~# ceph osd pool set <poolname> <key> <value>

DATA SERVICES
=============

TODO

DESIGN
======

TODO

HIGH AVAILABILITY
=================

TODO

LIFECYCLE
=========

TODO

MONITORING
==========

TODO

OPERATIONS
==========

To mount the Ceph file system::

  ~# mount -t ceph hostname1,hostname2:/ /mnt -o name=admin,secretfile=/etc/ceph/admin.secret

It is possible to do submounts. For instance, if the file system has a subdirectory ``/exports``::

  ~# mount -t ceph hostname1:/exports /mnt -o name=admin,secretfile=/etc/ceph/admin.secret

PATCHING
========

TODO

PERFORMANCE
===========

To perform a benchmark, use **rados**::

  ~# rados bench <seconds> <type> --pool=<poolname>

The **<type>** can be read or write.

QUALITY ASSURANCE
=================

TODO

EXTERNAL RESOURCES
==================

TODO

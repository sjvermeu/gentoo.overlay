==============
 aims_kerberos
==============

--------------------------
AIMS MIT Kerberos solution
--------------------------

:Author:        Sven Vermeulen <sven.vermeulen@siphos.be>
:Date:          2019-08-29
:Manual section:        8
:Manual group:          AIMS

DESCRIPTION
===========

The AIMS Kerberos solution provides support for a multi-master MIT Kerberos
setup.

AIMS DEVIATIONS
===============

AIMS slightly differentiates its installation from common Kerberos installations
for the following reasons:

- The state dir is set to ``/var/kerberos/krb5kdc`` instead of ``/var/krb5kdc``
  mainly because the default SELinux file contexts are for this location.
- AIMS has a principal with keytab stored as ``/root/.keytab.aims``. This keytab
  is (securely) copied towards each KDC.

ADMINISTRATION
==============

Managing Kerberos DB
--------------------

When a new MIT Kerberos setup is made, the database needs to be created first
(but AIMS will do this for you whenever the realm (through containers) is
created). This is done through the **kdb5_util** tool, or **kdb5_ldap_util**
when an LDAP back-end is used::

  ~# kdb5_util create -r INTERNAL.GENFIC.LOCAL -s

This will create the database in ``/var/kerberos/krb5kdc`` (as defined by the
``database_name`` property in ``kdc.conf``). It will also place a stash file (a
keytab file) there, which contains the password for handling the database.

See the DATA SERVICES section for handling backup/restore.

Managing principals
-------------------

To manage the principals, use the **kadmin** (networked) or **kadmin.local**
(direct DB access) tool. For instance, to create a principal
``admin/admin@INTERNAL.GENFIC.LOCAL``::

  kadmin: addprinc admin/admin
  Enter password for principal admin/admin@INTERNAL.GENFIC.LOCAL:
  Re-enter password for principal admin/admin@INTERNAL.GENFIC.LOCAL: 
  Principal "admin/admin@INTERNAL.GENFIC.LOCAL" created.

The various commands (to add, modify or delete principals) are well documented
on the MIT Kerberos documentation, or in the *kadmin(1)* manual page.

Replication
-----------

AIMS will automatically configure the Kerberos cluster to use incremental
replication. That means that, once the **kpropd** daemon is started, it will
authenticate itself (as ``kiprop/<fqdn>``) to the master and then pull the
changes as needed.

A few things are needed (but implemented by AIMS automatically) to accomplish
this:

- Each KDC must have a keytab (at ``/etc/krb5.keytab``) which contains both the
  host principal (``host/<fqdn>``) and the propagation principal
  (``kiprop/<fqdn>``) for said host. That also applies to the master.
- In the ``[realms]`` section of ``kdc.conf``, the following must be
  configured::

    iprop_enable = true
    iprop_port = 745

- In the ``kadm5.acl`` file, the propagation principals must be defined with the
  ``p`` privilege.

Replication is triggered automatically at certain intervals. If you want to
force a replication, on the slave, send the ``SIGUSR1`` signal to the **kpropd**
daemon::

  ~# pkill -SIGUSR1 kpropd

Managing keytabs
----------------

To create a keytab, you need to authenticate succesfully with kadmin first. This
can be password-based, but if you have a keytab that offers the appropriate
credentials, you can use it as well::

  ~$ kadmin -p <principal> -k -t <keytab>

If multiple realms are used, pass on the appropriate one::

  ~$ kadmin -r <realm> -p <principal> -k -t <keytab>

Within kadmin, you can add the keys of a principal to a keytab using **ktadd**::

  kadmin> ktadd host/kdc1.internal.genfic.local

This will add the key / principal to the default keytab, which is at
``/etc/krb5.keytab``. To select a different keytab, use the ``-k`` option::

  kadmin> ktadd -k /root/host.keytab host/kdc1.internal.genfic.local

To remove a key from the keytab, you first need to know which principal(s) are
in it. Use **klist** for this::

  ~$ klist -k -t /etc/krb5.keytab
  Keytab name: FILE:/etc/krb5.keytab
  KVNO Timestamp           Principal
  ---- ------------------- ------------------------------------------------------
    15 09/08/2019 15:17:19 host/kdc1.internal.genfic.local@INTERNAL.GENFIC.LOCAL
    ...

To remove the principal, use ``ktremove``::

  kadmin> ktrem host/kdc1.internal.genfic.local

It is possible that multiple versions of keys are in the keytab. You can select
the *key version number* to remove explicitly, or ask to remove all old ones
with ``old``::

  kadmin> ktrem host/kdc1.internal.genfic.local old

AUTHENTICATION
==============

MIT Kerberos supports three authentication methods. The default is
password-based, and is the most used. The other two are so-called
pre-authentication checks which can substitute the actual standard
authentication, and are generally associated with stronger authentication
methods: OTP-based, and PKINIT.

In this manual page, the PKINIT one is also explained.

Password-based
--------------

The default setup, as implemented by AIMS, is to use a password based
authentication approach (which is also the default approach for MIT Kerberos).

To authenticate a user (interactively), use the **kinit** command, like so::

  ~$ kinit name

This will contact the KDC and attempt to authenticate with the principal
``name@REALM`` (e.g. ``user1@INTERNAL.GENFIC.LOCAL``). If it is successful, then the
credential cache for the user will hae the appropriate principal active::

  ~$ klist
  Ticket cache: FILE:/tmp/krb5cc_1000
  Default principal: test@INTERNAL.GENFIC.LOCAL

  Valid starting       Expires              Service principal
  08/28/2019 21:33:19  08/29/2019 07:33:19  krbtgt/INTERNAL.GENFIC.LOCAL@INTERNAL.GENFIC.LOCAL
  renew until 08/29/2019 21:33:19

PKINIT
------

With PKINIT, MIT Kerberos also supports X509-based certificate authentication.
Here, both the KDC has to have a valid certificate (and key) as well as each
client. This can be enabled without affecting the principals that don't use
PKINIT based authentication (this is a per-principal setting).

Make sure that a common CA is used (e.g. using **certcli.sh** also part of AIMS)
and that the CA certificate is known in the truststores of the KDCs as well as
client.

For the KDC, sign the certificate request with the *kerberos-kdc* type, and set
the REALM environment variable accordingly::

  ~# env REALM="INTERNAL.GENFIC.LOCAL" certcli.sh --sign-request --parent genfic --type kerberos-kdc --output kdc.crt kdc.key

On the KDC, the private key (in unencrypted PEM format) and KDC certificate are
defined through the ``pkinit_identity`` parameter, whereas the truststore is set
through the ``pkinit_anchors`` parameter::

  [realms]
    INTERNAL.GENFIC.LOCAL = {
      ...
      # Support TCP as well as PKINIT might require larger packets than UDP allows
      kdc_tcp_listen = 88
      pkinit_identity = FILE:/etc/ssl/workspace/krb5/kdc.crt,/etc/ssl/private/krb5/kdc.pem
      pkinit_anchors = FILE:/etc/ssl/certs/root-genfic.crt
    }

As the ``krb5.conf`` file is replicated to the clients as well, either use
common names, or make sure that the replication substitutes certain values (TODO
for AIMS to support this).

For the clients, sign the certificate request with the *kerberos-client* type,
and set both REALM and PRINCIPAL environment variables accordingly. Use the
PRINCIPAL without REALM::

  ~# env REALM="INTERNAL.GENFIC.LOCAL" PRINCIPAL="user1" certcli.sh --sign-request --parent genfic --type kerberos-client --output user1.crt user1.key

Modify the principal(s) that require PKINIT based authentication by requiring
pre-authentication, and remove their current key(s) as these are now provided by
the certificate/private key::

  kadmin: modprinc +requires_preauth user1
  kadmin: purgekeys -all user1

Or, when the principal is immediately created for PKINIT based authentication::

  kadmin: addprinc +requires_preauth -nokey user1

Note that this can also be used for daemon-like principals (e.g.
``http/webhost.internal.genfic.local``) if they support PKINIT as authentication
method.

Users can authenticate themselves with their certificate and *kinit* like so::

  ~$ kinit -X X509_user_identity=FILE:~/.priv/user1.crt,~/.priv/user1.pem -p user1

AUTHORIZATION
=============

Principal authorizations
------------------------

Authorizations towards the database are set in the **kadm5.acl** file (see also
the *kadm5.acl(1)* manual page).

AUDITING
========

Authentication attempts are logged, by default, in the ``krb5kdc.log`` file on
the KDC where the authentication was done. Logging can be updated to send log
events to the system logger, allowing to centralize the events further. It is
also possible to send to multiple targets, like so::

  [logging]
    kdc = FILE:/var/log/krb5kdc.log
    kdc = SYSLOG:INFO:AUTH

BACKUP AND RESTORE
==================

Backing up the database
-----------------------

To back up the database, create a dump file that can then be sent off to the
backup service::

  ~$ kdb5_util dump /path/to/dumpfile

While backing up the stash file is possible as well, it is safer to recreate the
stash file based on the password used when creating the database.

Restoring the database
----------------------

To restore the database, retrieve the dumpfile that is backed up, and load it::

  ~$ kdb5_util load /path/to/dumpfile

To recreate the stash file::

  ~$ kdb5_util stash

CONFIGURATION
=============

Server configurations
---------------------

On the servers, the following configuration files are important to track:

The **krb5.conf** file is the main configuration file, listing not only the
realms and the KDCs for each realm, but also the properties for interacting with
the KDCs. This file is by default placed in ``/etc`` on both the Kerberos servers
as well as clients (although for the clients a smaller version can be used), 
but the location can be changed through the ``KRB5_CONFIG`` environment variable.

The **kdc.conf** file is the configuration file for the KDC servers, and is by
default placed in ``/var/lib/krb5kdc``, but the location can be changed through
the ``KRB5_KDC_PROFILE`` variable. This file contains the settings for the KDC
database.

ACL files
---------

MIT Kerberos uses ACL files to define who gets access to what. These ACL files
contain principals, which need to be defined in the Kerberos DB as well.

The **kadm5.acl** file, which is generally situated alongside the database (but
its location is defined by ``kdc.conf`` anyway - see ``acl_file`` property)
contains all the administrative principals and their actual privilege. To grant
them all the privileges, use ``*``.

While this file does not need to be on the KDC slaves, it is recommended to keep
it there as well in case you need to switch over mastership (and thus also run
the MIT Kerberos admin daemon on that host).

The **kpropd.acl** file, which is by default located in the same directory as
the *kdc.conf* file (so in ``/var/lib/krb5kdc``) called the KDC state directory,
contains the principals of the hosts that are allowed to retrieve database
updates. It is recommended that it also contains the principal for the main KDC
server in case you need to switch masters.

This file is only needed when **kpropd** is in use for the propagation. When
using the OpenLDAP back-end for instance, it is a common practice to use the
replication features of OpenLDAP itself (e.g. multi-master setup) rather than
using ``kpropd``.

Client configurations
---------------------

The client systems must have the **krb5.conf** file available as well, as this
file is needed for the Kerberos-aware services to know where the KDCs are, what
the default realm is, what properties are associated with the realm, etc.

DATA SERVICES
=============

Database
--------

To make a backup of the database, use the **kdb5_util** tool (or
**kdb5_ldap_util** in case of LDAP back-end) like so::

  ~$ kdb5_util dump <backupfilename>

To restore it::

  ~$ kdb5_util load <backupfilename>

Log files
---------

The **krb5kdc** daemon writes its log events to ``/var/log/krb5kdc.log``.

The **kadmind** daemon writes its log events to ``/var/log/kadmin.log``.

Credential caches
-----------------

The credential caches are temporal files that contain the TGT for a user or
session. By default, these are stored in ``/tmp`` and are named
``krb5cc_${USERID}``.

Keytabs
-------

Keytabs are long-term stores that contain the password (well, the shared key
that is otherwise build from the password) for one or more principals.
Applications that have (read) access to another keytab can easily use these
principals (impersonation risk). Proper protection of the keytabs is a must.

DESIGN
======

TODO

HIGH AVAILABILITY
=================

By default, AIMS will create a high available setup when the cluster has at
least two instances in it (one ``kadmin`` and one ``kdc``). To switch over
master from one instance to another:

- Lock the database for changes using **kadmin.local**::

    kadmin> lock

- Force a replication on the new master (with ``SIGUSR1`` towards **kpropd**)
- Shut down or kill the ``kadmind`` process on the old master
- Unlock the database for changes (using ``unlock``)
- Shut down ``kpropd`` on the new master
- Start ``kadmind`` on the new master
- Update the ``krb5.conf`` file(s) on the clients (or change the DNS)
- Start ``kpropd`` on the old master

If the master crashed, start ``kadmind`` on the new master after shutting its
``kpropd`` down. When the old master comes up again, make sure ``kadmind`` isn't
started again (and if it does, make sure clients don't find it as the master
through DNS changes for instance) and start ``kdc`` on it.

LIFECYCLE
=========

TODO

MONITORING
==========

TODO

OPERATIONS
==========

Gentoo Linux
------------

On Gentoo, the services are called ``mit-krb5kdc`` (for the KDCs), 
``mit-krb5kadmind`` (for the Kerberos Admin service) and
``mit-krb5kpropd`` (for the replication services).

Generic Linux
-------------

The MIT Kerberos daemons can be launched directly as well. They automatically
daemonize unless you explictly ask them not to::

  ~# krb5kdc
  ~# kadmind
  ~# kropd

However, keep in mind that this will not automatically run these services in the
appropriate SELinux context!

Pre-authentication
------------------

When a principal is mandated to require pre-authentication (such as pkinit), you
can test this out with kinit, assuming you have the client key (client.pem) and
certificate (client.crt)::

  ~$ kinit -X X509_user_identity=FILE:client.crt,client.pem <principal>

Changing password
-----------------

End users or principal owners can change their own password using the
**kpasswd** command.

PATCHING
========

TODO

PERFORMANCE
===========

TODO

QUALITY ASSURANCE
=================

TODO

EXTERNAL RESOURCES
==================

TODO

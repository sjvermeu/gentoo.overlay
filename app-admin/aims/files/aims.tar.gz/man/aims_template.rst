==============
 aims_SERVICE
==============

---------------------
AIMS SERVICE solution
---------------------

:Author:        Sven Vermeulen <sven.vermeulen@siphos.be>
:Date:          2015-07-02
:Manual section:        8
:Manual group:          AIMS

DESCRIPTION
===========

For *emphasis* or **highlights** or ``verbatim``.

For examples::

  ~# useradd --system neo4j

AIMS DEVIATIONS
===============

AIMS slightly differentiates its installation from common Kerberos installations
for the following reasons:

- Reason 1
- Reason 2

ADMINISTRATION
==============

TODO

AUTHENTICATION
==============

TODO

AUTHORIZATION
=============

TODO

AUDITING
========

TODO

BACKUP AND RESTORE
==================

TODO

CONFIGURATION
=============

TODO

DATA SERVICES
=============

TODO

DESIGN
======

TODO

HIGH AVAILABILITY
=================

TODO

LIFECYCLE
=========

TODO

MONITORING
==========

TODO

OPERATIONS
==========

All operations are supported through the service script.

stop | start | restart
  Stop, start or restart the service.

PATCHING
========

TODO

PERFORMANCE
===========

TODO

QUALITY ASSURANCE
=================

TODO

EXTERNAL RESOURCES
==================

TODO

=================
 aims_postgresql
=================

------------------------
AIMS PostgreSQL solution
------------------------

:Author:        Sven Vermeulen <sven.vermeulen@siphos.be>
:Date:          2015-06-12
:Manual section:        8
:Manual group:          AIMS

DESCRIPTION
===========

The **postgresql** service offers a complete database solution based on the
PostgreSQL database platform.

ADMINISTRATION
==============

TODO

AUTHENTICATION
==============

Authentication is preferably done through PAM. The ``pg_hba.conf`` file sets the
*method* to ``pam``, and can optionally point to the right pam service through
the *pamservice* option::

  host   all     all     all      pam     pamservice=aims

AUTHORIZATION
=============

Authorizations are pulled in through **aims-auth-apply**. Do not forget to configure
the ``aims.conf`` file accordingly!

AUDITING
========

The logging as suggested for performance management includes sufficient information
for auditing, but is an all-or-nothing approach. It is also possible to include an 
audit trigger.

See https://wiki.postgresql.org/wiki/Audit_trigger_91plus for more information.

On the development mailinglist there is some chatter about the 9.5 release which
would contain more auditing capabilities.

BACKUP AND RESTORE
==================

Using base backup and WAL
-------------------------

First configure PostgreSQL for point-in-time restores. See `Setup for point-in-time
restores`_ for details on this.

Next, schedule base backups (which are full backups) at regular time intervals::

  pg_basebackup -D /destdir -X stream -Ft -z -P -U postgres

The ``/destdir`` is a directory in which the backup is placed. This directory must
be writable by the run-time user (and SELinux context). The ``postgres`` in the
example is the user through which the base backup is taken. With ``-Ft`` a tarball
is created, which is compressed (``-z``). During the backup, progress (``-P``) is
shown. The backup also includes the necessary transaction logs (``-X stream``) to
support a clean restore.

The user needs to have replication privileges, or be a superadmin.

The end result is at least one tarball called ``base.tar.gz`` (other tarballs can 
exist, one for each tablespace) which together are a full backup. To restore
this, extract the contents (with privilege preservation) in an (empty) data directory.
If possible, copy all previously known WAL segments from ``pg_xlog`` back into this
location.

Next, create a ``recovery.conf`` file (don't forget the symlink it into the
data directory) which contains the *restore_command* needed to copy back archive files
into the right location::

  restore_command = 'cp /var/lib/postgresql/archive/%f "%p"'

Temporarily disallow remote logins to the database (through ``pg_hba.conf``) until
the database is restored.

Using LVM snapshots
-------------------

Another method is to use snapshotting. The simplest method is to make sure that all
files related to the database are on a single logical volume, so that the snapshot
is taken atomically.

If this is not the case, it is necessary to call *pg_start_backup* and
*pg_stop_backup*. In between, take the necessary snapshot(s). Then (after the
database is back live) make sure that the snapshot's ``pg_xlog`` points to the
other snapshot (instead of real volume).

The snapshot can then be backed up accordingly. This is a crash-consistent backup,
but with a ``recovery.conf`` file this can be used for point-in-time restores.

CONFIGURATION
=============

A number of configuration highlights are explained here.

Setup for point-in-time restores
--------------------------------

To configure PostgreSQL for point-in-time restores, a number of settings need
to be changed in the ``postgresql.conf`` configuration file:

wal_level = archive
  By default, ``wal_level`` is set to ``minimal``. For point-in-time restores,
  this needs to be set to at least ``archive``.

archive_mode = on
  This will ensure that PostgreSQL, after closing a WAL segment, executes the 
  archive command to back up the WAL archive.

archive_command = ...
  This command needs to be set to back up the archive, and return 0 if succesful.
  An example command could be any of the following::

  'test ! -f /dest/%f && cp %p /dest/%f'
  'test ! -f /dest/%f.gz && gzip < %p > /dest/%f.gz'

max_wal_senders = 2
  By default, ``max_wal_senders`` is set to 0. However, when a base backup is taken
  using the **pg_basebackup** command, this command will connect to the replication
  service. This requires at least one WAL sender. With the *stream* method, an
  additional sender is used.

Inside the ``pg_hba.conf`` file, a replication needs to be set. For instance, for a
locally invoked backup using the ``postgres`` PostgreSQL user::

  local         replication             postgres                trust

DATA SERVICES
=============

TODO

DESIGN
======

TODO

HIGH AVAILABILITY
=================

To set up high availability, create a streaming replication standby system.

On the primary, configure a database user with replication privileges::

  psql> CREATE USER rep REPLICATION LOGIN CONNECTION LIMIT 1;

In the ``pg_hba.conf`` file, enable the replication from the standby systems (addresses).

If synchronous replication is needed, set *synchronous_standby_names* to the value
of *application_name* in the standby's ``postgresql.conf``.

On the standby, configure the system with the following ``recovery.conf``::

  standby_mode = 'on'
  primary_conninfo = 'host=<source IP> port=<port> user=<repluser> password=<pass>'
  restore_command = 'test -f /dest/%f && cp /dest/%f "%p"'
  archive_cleanup_command = 'pg_archivecleanup /dest %r'

LIFECYCLE
=========

TODO

MONITORING
==========

TODO

OPERATIONS
==========

All operations are supported through the service script.

stop | start | restart
  Stop, start or restart the service.

reload
  Reload the configuration files (for those settings that can be applied live)

promote
  To be executed on a standby system, this enables the database for read-write
  operations (effectively turning into a master database).

PATCHING
========

TODO

PERFORMANCE
===========

Some performance highlights.

Tuning in postgresql.conf
-------------------------

The defaults in the ``postgresql.conf`` file are most likely not sufficient for
larger deployments. Hence, the following parameters are best updated:

shared_buffers = 2GB
  The default is around 128Mb. A setting of 2Gb is a good setting for an 16Gb RAM system.

work_mem = 64MB
  The default is 4Mb. A setting of 64MB is good for an 16Gb RAM system.

maintenance_work_mem = 512MB
  The default is 64Mb.

checkpoint_segments = 64
  Default is 3.

checkpoint_completion_target = 0.9
  Default is 0.5.

effective_cache_size = 8GB
  Default is 4GB

QUALITY ASSURANCE
=================

TODO

EXTERNAL RESOURCES
==================

TODO

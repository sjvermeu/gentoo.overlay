===============
 aims_virtualdc
===============

---------------------------------
AIMS Virtual Data Center solution
---------------------------------

:Author:        Sven Vermeulen <sven.vermeulen@siphos.be>
:Date:          2019-08-24
:Manual section:        8
:Manual group:          AIMS

DESCRIPTION
===========

The _virtualdc_ solution in the AIMS framework provides a simple interface to
launch virtual machines based on template images.

ADMINISTRATION
==============

Important advice
----------------

When using tun/tap based networking, make sure that the runtime user (also
SELinux user in case of UBAC) has ownership of the TAP device that has been
created. For instance, if they are created with `sysadm_u` then the SELinux user
of Qemu must also be `sysadm_u`.

Furthermore, due to the use of tap devices and bridges, make sure that, once the
VM is launched, that the devices are actually UP in state.

  ~# ip link list

Bring the tap device up explictly like so:

  ~# ip link set dev tap-test up

The bridge device should automatically become UP as well.

If the DHCP fails to work, this is generally because the bridge is not up.

Compressing the qemu images
---------------------------

When an instance is created, it is made of a copy of the `base/default.img`
file. This file is created by copying the `bootstrap/hardened-base.img` while
running the *qemu-img* command to unlink any empty blocks in the image:

  ~# qemu-img convert -O qcow2 bootstrap/hardened-base.img base/default.img

You can also enable compression (with `-c`) although this has some performance
impact:

  ~# qemu-img convert -O qcow2 -c bootstrap/hardened-base.img base/default.img

Hot-add CPUs
------------

It is possible to hot-add CPUs through the Qemu console (reachable through the
screen sessions) as follows::

  qemu> device_add driver=kvm64-x86_64-cpu,id=cpu3,socket-id=2,core-id=0,thread-id=0

To remove the CPU again::

  qemu> device_del id=cpu3

AUTHENTICATION
==============

In general, the following accounts are pre-created on the images: root (with
password ``rootpass``), admin (``adminpass``), oper, and user (all with similar
passwords).


AUTHORIZATION
=============

TODO

AUDITING
========

TODO

BACKUP AND RESTORE
==================

TODO

CONFIGURATION
=============

Node configuration
------------------

The nodes / images that virtualdc uses preferably use the following settings:

- NFS mounts should use ``timeo=10`` (1 second timeout), ``retrans=1``
  (retransmit one time) and (especially) ``retry=0`` (don't retry further).

TODO

DATA SERVICES
=============

TODO

DESIGN
======

TODO

HIGH AVAILABILITY
=================

TODO

LIFECYCLE
=========

TODO

MONITORING
==========

TODO

OPERATIONS
==========

To launch a virtual machine, go to the base location where the guests are
located (generally /srv/virt/gentoo/guests), enter the subdirectory of the
guest, and then use *host-operate.sh*:

  ~# ./host-operate.sh start

To connect to a running instance, use the *connect* argument:

  ~# ./host-operate.sh connect

To launch the image with a certain media (most likely ISO file) mounted, use 
the *media* argument followed by the path to the media file:

  ~# ./host-operate.sh media /srv/virt/gentoo/media/gentoo.iso

PATCHING
========

TODO

PERFORMANCE
===========

TODO

QUALITY ASSURANCE
=================

TODO

EXTERNAL RESOURCES
==================

TODO

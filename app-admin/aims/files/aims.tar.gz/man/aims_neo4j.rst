============
 aims_neo4j
============

------------------------
AIMS Neo4J solution
------------------------

:Author:        Sven Vermeulen <sven.vermeulen@siphos.be>
:Date:          2015-07-02
:Manual section:        8
:Manual group:          AIMS

DESCRIPTION
===========

The **neo4j** service offers a Neo4J solution.

Before creating Neo4J instances, first create a Neo4J user::

  ~# useradd --system neo4j

When extracting the Neo4J software tarball, do this in ``/opt`` so that the
resulting path is something like ``/opt/neo4j-enterprise-2.3.0``. Don't forget
to set the ownership correctly::

  ~# chown -R root:root /opt/neo4j*

ADMINISTRATION
==============

TODO

AUTHENTICATION
==============

Neo4J does not truly support authentication and authorization. It has an
authentication database file at ``/var/lib/neo4j/instances/*/dbms/auth`` which
contains userid and (salted) password. Within AIMS, a helper script called
*create-auth.sh* is added in the ``libexec/systems/neo4j`` location.

After updating the file, restart the Neo4J service.

AUTHORIZATION
=============

Implementing authorization in Neo4J is done by extending the code. There is no
infrastructural support to do so automatically.

AUDITING
========

Implementing auditing in Neo4J is done by extending the code. There is no
infrastructural support to do so automatically.

BACKUP AND RESTORE
==================

Extracting a backup
-------------------

When using the Enterprise Edition, a backup service is usually listening on port
6362 (localhost, but with ``online_backup_server`` this can be changed to any
address).

The *neo4j-backup* command can be used to create a backup. This will result in a
copy of the entire data directory, ready for backing up::

  ~# neo4j-backup -host 127.0.0.1 -to /srv/backups/neo4j-backup

Incremental backups are automatically done when the target already exists.

Restoring is a matter of moving all backed up files into the data directory.

CONFIGURATION
=============

Almost all configuration aspects are done in the ``neo4j.properties`` and 
``neo4j-server.properties`` files.

See http://neo4j.com/docs/stable/server-configuration.html for more information.

DATA SERVICES
=============

Loading data
------------

See http://neo4j.com/docs/stable/query-load-csv.html for more information.

DESIGN
======

No information available yet.

HIGH AVAILABILITY
=================

To set up a high available cluster, use AIMS' **multi-master** type when creating the
cluster::

  ~# aims cluster create -s neo4j -t multi-master neo4j

When creating an instance, make sure to add the ``cluster_hosts`` option to mention
the initial hosts that the cluster will use::

  ~# aims instance create -c neo4j -o remote_access=1,node=1,cluster_hosts=test+test2 neo4j

Use the ``+`` sign to mention multiple hosts.

LIFECYCLE
=========

When upgrading Neo4J, the database is usually automatically converted at start-up.
Sometimes explicit configuration changes are needed. These are usually bundled in 
a specific configuration parameter (``allow_store_upgrade=true`` in ``neo4j.properties``).

When explicit configuration changes are needed, an automatic conversion will
not take place. Instead, the database will refuse to start.

MONITORING
==========

It is possible to write monitors based on JMX, but no experience with this yet.

OPERATIONS
==========

All operations are supported through the service script.

stop | start | restart
  Stop, start or restart the service.

PATCHING
========

Not needed yet.

PERFORMANCE
===========

Neo4J performance is related to

* java JVM tuning (mempry and garbage collections)
* decent I/O and sufficient memory

QUALITY ASSURANCE
=================

Not investigated yet.

EXTERNAL RESOURCES
==================

* http://neo4j.com/docs/stable/
* https://github.com/jexp/neo4j-shell-tools

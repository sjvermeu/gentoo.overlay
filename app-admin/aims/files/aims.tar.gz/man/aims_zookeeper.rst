==============
 aims_SERVICE
==============

---------------------
AIMS SERVICE solution
---------------------

:Author:        Sven Vermeulen <sven.vermeulen@siphos.be>
:Date:          2015-07-02
:Manual section:        8
:Manual group:          AIMS

DESCRIPTION
===========

For *emphasis* or **highlights** or ``verbatim``.

For examples::

  ~# useradd --system neo4j

ROUGH NOTES
===========

This section will be removed later on when things are automated, right now it is
to track knowledge.

The default configuration by Gentoo is in /opt/zookeeper-bin/conf. Instead, we
create (mkdir -p) /etc/opt/zookeeper, then place the zoo.cfg file in there.
Then, in /etc/conf.d/zookeeper we update the configuration location.

In /var/lib/zookeeper, create a ``myid`` file that has the ID for the zookeeper
instance. That instance corresponds with the one in the configuration file::

  tickTime=2000
  initLimit=5
  syncLimit=2
  dataDir=/var/lib/zookeeper
  clientPort=2181
  # Replication cluster
  server.1=zk1:2888:3888
  server.2=zk2:2888:3888
  server.3=zk3:2888:3888

Configuring some zookeeper parameters is done through Java properties. E.g. for
enabling JMX support, in /etc/conf.d/zookeeper::

  # JVM options
  JVM_OPTS=""
  #JVM_OPTS="${JVM_OPTS} -Dzookeeper.log.dir=/var/log/zookeeper"
  #JVM_OPTS="${JVM_OPTS} -Dzookeeper.root.logger=/etc/opt/zookeeper/log4j.conf"
  JVM_OPTS="${JVM_OPTS} -Dcom.sun.management.jmxremote"
  JVM_OPTS="${JVM_OPTS} -Dcom.sun.management.jmxremote.local.only=false"
  JVM_OPTS="${JVM_OPTS} -Dcom.sun.management.jmxremote.port=1234"
  JVM_OPTS="${JVM_OPTS} -Dcom.sun.management.jmxremote.authenticate=true"
  JVM_OPTS="${JVM_OPTS} -Dcom.sun.management.jmxremote.password.file=/etc/opt/zookeeper/jmx.auth"
  JVM_OPTS="${JVM_OPTS} -Dcom.sun.management.jmxremote.ssl=true"
  JVM_OPTS="${JVM_OPTS} -Djava.security.auth.login.config=/etc/opt/zookeeper/jaas.conf"
  #JVM_OPTS="${JVM_OPTS} -Dzookeeper.jmx.log4j.disable=false"

Finding out the version of ZooKeeper that is running (you might need to install
the netcat package)::

  ~$ echo status | nc localhost 2181
  Zookeeper version: 3.4.13-2d71a...03, built on 06/09/2018 04:05 GMT

By default, ZooKeeper works unauthenticated. Enable SASL support to ensure only
authenticated identities can be used (also for cross-cluster communication).
This is done through the ``zoo.cfg`` configuration file::

  # SASL support
  quorum.auth.enableSasl=true
  quorum.auth.learnerRequireSasl=true
  quorum.auth.serverRequireSasl=true
  quorum.auth.learner.loginContext=QuorumLearner # is default
  quorum.auth.server.loginContext=QuorumServer # is default
  quorum.auth.kerberos.servicePrincipal=zkquorum/zk1.internal.genfic.local
  quorum.cnxn.threads.size=20 # at least 2*clustersize

The SASL credentials to be used as defined in a configuration file (e.g.
``jaas.conf``) only readable by ZooKeeper, and pointed towards through
the ``java.security.auth.login.config`` variable (to be set as JVM parameter).

To ensure logging works properly, make sure that the path that contains
``log4j.properties`` is in the classpath.

AIMS DEVIATIONS
===============

AIMS slightly differentiates its installation from common Kerberos installations
for the following reasons:

- Reason 1
- Reason 2

ADMINISTRATION
==============

TODO

AUTHENTICATION
==============

TODO

AUTHORIZATION
=============

TODO

AUDITING
========

TODO

BACKUP AND RESTORE
==================

TODO

CONFIGURATION
=============

TODO

DATA SERVICES
=============

TODO

DESIGN
======

TODO

HIGH AVAILABILITY
=================

TODO

LIFECYCLE
=========

TODO

MONITORING
==========

TODO

OPERATIONS
==========

All operations are supported through the service script.

stop | start | restart
  Stop, start or restart the service.

PATCHING
========

TODO

PERFORMANCE
===========

TODO

QUALITY ASSURANCE
=================

TODO

EXTERNAL RESOURCES
==================

TODO

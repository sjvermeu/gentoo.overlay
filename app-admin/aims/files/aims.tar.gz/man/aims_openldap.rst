=================
 aims_openldap
=================

------------------------
AIMS OpenLDAP solution
------------------------

:Author:        Sven Vermeulen <sven.vermeulen@siphos.be>
:Date:          2016-05-23
:Manual section:        8
:Manual group:          AIMS

DESCRIPTION
===========

The **openldap** service offers a complete LDAP solution based on the
OpenLDAP software.

CONFIGURATION
=============

Enabling SSL/TLS Support
------------------------

In the ``aims-slapd-instance.conf.local`` file there are a number of TLS related
settings available (but commented out). Uncomment those, and make sure that the
keys they refer to exist::

  TLSCACertificatePath  /etc/ssl/certs
  TLSCertificateFile    /etc/ssl/<hostname>/<hostname>.crt
  TLSCertificateKeyFile /etc/ssl/<hostname>/private/<hostname>.key
  TLS_REQCERT           allow # strict, never

The keys can be created using the **certcli.sh** script.

Then run **aims reapply** to rebuild the configuration.

Make sure that:

  - OpenLDAP's slapd is started with (only) the ldaps:// listener.
  - LDAP clients are configured to use SSL/TLS as well

Configuring the listener
------------------------

The listener (which is part of the *slapd* daemon) is configured through
the ``-h`` option. For instance, to only allow non-encrypted connections
through localhost and SSL/TLS encrypted connections globally::

  -h 'ldap://127.0.0.1/ ldaps:///'

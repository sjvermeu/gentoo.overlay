# Automatic Infrastructure Management System

Author
: Sven Vermeulen

License
: Currently no license assigned unless explicitly mentioned.

Purpose
: A proof of concept for an _infrastructure service pattern_ 

Overview
========

The *Automatic Infrastructure Management System* is a collection of scripts meant
to provide a prototype approach towards a method for managing infrastructure services.
This method can very well be implemented in configuration management utilities such
as _saltstack_, and eventually this structure will be shown through the `virtualdc`
repository.

The infrastructure service pattern that it implements is as follows::

                    COMPONENT
                     [comp]
                       |
                       |
                    SOLUTION
                     [sol]
                       |
                       |
      CAPABILITY----SERVICE----TYPE
        [cap]        [svc]    [type]
                       |       |  
                       |       |
                    CLUSTER    |
                     [cls]     |
                    /     \    |
                   /       \   |
              INSTANCE  CONTAINER
               [inst]    [cntr]
                 |
                 |
             RESOURCE
              [res]


  * A *component* is a building block, generally a single technology, which is offered
    through an expertise team and is used to build larger services. A common example is
    a database technology, the Java VM, etc.
  * A *solution* is a collection of *components* that build up a finished product.
    Solutions have a finished set of documentation, tests, etc. For instance, a Neo4J
    solution can be built through the Neo4J component, Nginx component and Java component.
  * A *service* is a logical phase through the instantiation of a *solution*. Services
    have service levels assigned to them, and can be linked through *capabilities* (something
    that a service offers) with each other, and support *types*. An example service could
    be a "Production OpenLDAP service"
  * A *cluster* is a collection of similarly configured *instances*, generally meant to provide
    a particular availability. An example could be a multi-master PostgreSQL deployment.
  * An *instance* is a running daemon which implements the necessary services for the *cluster*,
    and is used to host the *containers*. Examples are the `slapd` daemons (for OpenLDAP), 
    `master` daemons (for PostgreSQL), etc.
  * A *container* is a deployment unit, often of a particular *type*, which is generally
    associated with a user or set of users. It is the final part of an infrastructure
    service and is that what the infrastructure service users come in contact with. Example
    containers are PostgreSQL databases, OpenLDAP Directory Information Trees, etc.
  * A *resource* is a depletable item specific to the instance, which can be used to allocate
    the right instance in a cluster to a container.

A more detailed definition, as well as more examples, are given in the next sections.

Components
----------

Definition
: A reusable building block, with well established usage guidelines and configuration freedom.
  Generally provided and managed by a technology expert team.

The offering of a component should be accompanied with expert documentation and procedures
on how to deal with the component. Components generally are released through dedicated
projects and molded towards the rules and regulations of the environment. So even though
OpenLDAP (as technology, which can be offered as a component) can be used in a large number
of definitions and configurations, the _openldap component_ itself is more limited.

This limitation is to make sure that the usage of the component can be well supported.
If the support team for the OpenLDAP technology does not want to support the olc (OnLine
Configuration) setup yet, then they will not offer this through the component, even though
the technology itself can support it easily.

But although the expert team defines how the technology can (and can't) be used, it is
not a fully finished service. Most components need to be integrated. Additional components
might need to be bundled and used in a particular manner before we can speak of a somewhat
finished product. Such combination and usage set is called a *solution*.

Solutions
---------

Definition
: A finished "product" that combines one or more components into a usable set, ready for 
  instantiation. Together with the right set of documentation and deployment guidelines,
  solutions are used to build enterprise-ready services.

Solutions are what most engineering effort is put into. They combine the functionalities
of several components, integrate those into a solution together with the necessary end-user
and administration documentation, lifecycle et cetera.

Within the AIMS application, solutions provide the scripts needed to operationalize services.
Inside the `libexec` location of a solution, all the integration logic is kept to quickly
create runnable solutions.

Services
--------

Definition
: A logical approach for an instantiated solution, services are generally used to bundle
  service level and other agreements with customers and business units.

A service is generally a lightweight or often even logical implementation of a solution.
Within a service, one or more clusters are defined. On the service level, SLAs as well
as authorizations (on service level) are applied.

Capability
----------

TODO

Types
-----

TODO

Clusters
--------

Definition
: A cluster is a set of instances of a particular technology who work together to offer the
  right set of services towards a "container".

Clusters are positioned to handle resource control as well as capacity management. A service
can contain multiple clusters, but within a single service, all clusters should have the same
SLA. The use of multiple clusters is generally for capacity reasons.


Instances
---------

Definition
: An instance is an instantiated software that enables the necessary interfaces / services
  for a container, and is needed to make a cluster available.

Instances are generally what most administrators physically notice. It can be a runtime master
for a database, or a KVM host on which VMs can be deployed. Unlike clusters, who are more 
logical in nature, instances really exist and are used to interact with.

Resources
---------

TODO

Containers
----------

Definition
: A container is the end service offered by a solution / service / cluster, and is generally
  what end users use of the solution.

A container is hosted on a cluster (but implemented on one or more instances).

Structure
=========

TODO

Solution Documentation
======================

Each solution is accompanied with a full document, available in both ReStructured Text
as well as a manual page on the system, and contains a number of sections that explain
a solution in more detail. These sections should offer all information generally needed
for administrators and users to work with the solution.

  1. Administration (processes, authorizations, procedures, but also lifecycle and patching)
  2. Authentication
  3. Authorization
  4. Auditing and logging
  5. Configuration management
  6. Data management (data handling, definition, governance and lineage, backup/resture)
  7. Design and development
  8. High availability and disaster recovery
  9. Operations
  10. Performance management
  11. Quality assurance
  12. Roadmap and restrictions
#!/bin/sh

die() {
  echo "!!! $*"
  exit 1;
}

help() {
  echo "Usage: $0 [start|connect|media]"
  echo "  start		Start the virtual machine"
  echo "  connect	Conncet to the VM through VNC"
  echo "  media		Boot the media as provided through the second argument"
}

if [ $# -eq 0 ] || [ "$1" = "help" ] ; then
  help;
  exit 0;
fi

# Check if local files exist
for file in rootfs.img swap.img ro-settings.conf settings.conf ; do
  [ -f ${file} ] || [ -h ${file} ] || die "${file} is not available"
done

# Source settings
for file in ro-settings.conf settings.conf ; do
  source ./${file};
done

if [ ! -d /sys/class/net/tap-${HOSTNAME} ] && [ ! -l /sys/class/net/tap-${HOSTNAME} ] ; then
  echo "Please run following as root first:"
  echo "ip tuntap add dev tap-${HOSTNAME} mode tap group ${GROUP}"
  echo "ip link set tap-${HOSTNAME} master ${BRIDGE_NAME}"
  echo "ip link set tap-${HOSTNAME} up"

  exit 1;
fi

CMD=$1;
OPT=$2;

if [ "${CMD}" = "start" ] ; then
  ## 
  ## START THE VM
  ##
  
  # Check if the guest is already running
  fuser rootfs.img > /dev/null 2>&1;
  if [ $? -eq 0 ] ; then
    die "Guest is already running (or rootfs.img is in use)."
  fi

  RUNCMD="
/usr/bin/qemu-system-x86_64 -enable-kvm -cpu kvm64 \
-gdb tcp::${GDB_PORT} \
-device e1000,netdev=${HOSTNAME},mac=${MAC_ADDRESS} \
-netdev tap,id=${HOSTNAME},ifname=tap-${HOSTNAME},script=no,downscript=no \
-drive file=rootfs.img,if=virtio,cache=writeback \
-drive file=swap.img,if=virtio,cache=writeback \
-m ${MEMORY} \
-smp ${CPUCOUNT},maxcpus=16 \
-monitor stdio -vnc ${BRIDGE_ADDRESS}:${VNC_PORT}";

  echo "Running following command inside screen, output in output.log: ${RUNCMD}"

  screen -S kvm-${HOSTNAME} -dm sh -c "${RUNCMD} 2>&1 | tee output.log 2>&1"

elif [ "${CMD}" = "connect" ] ; then
  ## 
  ## CONNECT THROUGH VNC
  ##

  vncviewer ${BRIDGE_ADDRESS}:$(echo ${VNC_PORT}+5900 | bc)
elif [ "${CMD}" = "media" ] ; then
  ## 
  ## BOOT WITH GIVEN MEDIA
  ##

  if [ ! -f "${OPT}" ] ; then
    die "Media file ${OPT} does not exist";
  fi

  # Check if the guest is already running
  fuser rootfs.img > /dev/null 2>&1;
  if [ $? -eq 0 ] ; then
    die "Guest is already running (or rootfs.img is in use)."
  fi

  RUNCMD="
/usr/bin/qemu-system-x86_64 -enable-kvm -cpu kvm64 \
-gdb tcp::${GDB_PORT} \
-device e1000,netdev=${HOSTNAME},mac=${MAC_ADDRESS} \
-netdev tap,id=${HOSTNAME},ifname=tap-${HOSTNAME},script=no,downscript=no \
-drive file=rootfs.img,if=virtio,cache=writeback \
-drive file=swap.img,if=virtio,cache=writeback \
-boot d -cdrom ${OPT}
-m ${MEMORY} \
-smp ${CPUCOUNT},maxcpus=16 \
-monitor stdio -vnc ${BRIDGE_ADDRESS}:${VNC_PORT}";

  echo "Running following command inside screen, output in output.log: ${RUNCMD}"

  screen -S kvm-${HOSTNAME} -dm -sh -c "${RUNCMD} 2>&1 | tee output.log 2>&1"

fi

#!/bin/sh

echo "Updating make.conf"
cat > /etc/portage/make.conf << EOF
COMMON_FLAGS="-O2 -pipe"
CFLAGS="${COMMON_FLAGS}"
CXXFLAGS="${COMMON_FLAGS}"
FCFLAGS="${COMMON_FLAGS}"
FFLAGS="${COMMON_FLAGS}"

# NOTE: This stage was built with the bindist Use flag enabled
PORTDIR="/usr/portage"
DISTDIR="/var/cache/distfiles"
PKGDIR="/var/cache/binpkgs"

# This sets the language of build output to English.
# Please keep this setting intact when reporting bugs.
LC_MESSAGES=C

# Use flags
USE="ssl openssl -unconfined audit python"

# SELinux settings
POLICY_TYPES="mcs"
EOF

echo "Switching profile"
NUM=$(eselect --color=no profile list | grep no-multilib/hardened/selinux | sed -e 's:.*\[::g' -e 's:\].*::g' | tail -1);
eselect profile set ${NUM}

echo "Installing base policy"
FEATURES="-selinux" emerge -1 selinux-base

echo "Setting up SELinux configuration"
cat > /etc/selinux/config << EOF
SELINUX=permissive
SELINUXTYPE=mcs
EOF

echo "Installing base policy again"
FEATURES="-selinux -sesandbox" emerge -1 selinux-base
FEATURES="-selinux -sesandbox" emerge selinux-base-policy

echo "Updating world"
emerge -uDkN @world

echo "Updating /etc/fstab for SELinux"
cat > /etc/fstab << EOF
/dev/vda2               /boot   ext2    noauto,noatime  1 2
/dev/vda3               /       ext4    noatime         0 1
/dev/vdb1               none    swap    sw              0 0
# Additional resources
workstation4:/usr/portage                       /usr/portage            nfs4    defaults        0 0
workstation4:/srv/virt/nfs/gentoo/packages      /var/portage/packages   nfs4    defaults        0 0
workstation4:/srv/virt/nfs/gentoo/overlays	/var/portage/overlays	nfs4	defaults	0 0
# SELinux settings
tmpfs   /tmp    tmpfs   defaults,noexec,nosuid,rootcontext=system_u:object_r:tmp_t:s0           0 0
tmpfs   /run    tmpfs   mode=0755,nosuid,nodev,rootcontext=system_u:object_r:var_run_t:s0       0 0
EOF


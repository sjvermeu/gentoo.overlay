#!/bin/sh

vncviewer :11

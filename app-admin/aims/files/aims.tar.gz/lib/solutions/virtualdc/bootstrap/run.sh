#!/bin/sh

export VNCPORT=11
export GDBPORT=1100
export MAC_ETH0="00:11:22:33:44:b0"
export IMAGE=/srv/virt/gentoo/bootstrap/hardened-base.img
export SWAPIMAGE=/srv/virt/gentoo/bootstrap/swap.img
export CDIMAGE=/srv/virt/media/systemrescuecd-6.0.3.iso
export MEM=1536

export KVM="/usr/bin/qemu-system-x86_64 -enable-kvm"
export KEYBOARD=en-us
export CPU=kvm64

export TAPDEVICE="tap-bootstrap"
export BRIDGE="br-dc0"
export GROUP="kvm"

if [ ! -d /sys/class/net/${TAPDEVICE} ] ; then
  echo "Please run following as root first:"
  echo "ip tuntap add dev ${TAPDEVICE} mode tap group ${GROUP}"
  echo "ip link set ${TAPDEVICE} master ${BRIDGE}"

  exit 1;
fi

RUNCMD="${KVM} -gdb tcp::${GDBPORT} -vnc 127.0.0.1:${VNCPORT} \
  -device e1000,netdev=testnet,mac=${MAC_ETH0} \
  -netdev tap,id=testnet,ifname=${TAPDEVICE},script=no,downscript=no \
  -drive file=${IMAGE},if=virtio,cache=writeback \
  -drive file=${SWAPIMAGE},if=virtio,cache=writeback \
  -cdrom ${CDIMAGE} -boot d -k ${KEYBOARD} \
  -m ${MEM} -cpu ${CPU} -smp 2 -monitor stdio"

echo "Executing ${RUNCMD}"

${RUNCMD}

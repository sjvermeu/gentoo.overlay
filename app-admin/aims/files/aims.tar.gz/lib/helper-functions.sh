##
## AIMS helper functions
##

# findfile <rootpath> <file>
findfile() {
  LOCATECMD=$(whereis -b locate | awk '{print $2}');
  FINDCMD=$(whereis -b find | awk '{print $2}');
  if [ -x ${LOCATECMD} ] ; then
    locate "$2" | grep -E "${2}$" | grep -E "^${1}"; 
  elif [ -x ${FINDCMD} ] ; then
    find "${1}" | grep -E "${2}$"
  fi
}

# getValueForKey <file> <key>
# Beware: <key> can be a regular expression!
getValueForKey() {
  local fromfile="$1";
  local key="$2";

  grep -E "^${key}=" ${fromfile} | sed -e 's:^[^=]*=::g' | sed -e 's:^"\(.*\)"$:\1:g';
}

# setValueForKey <file> <key> <value>
setValueForKey() {
  local tofile="$1";
  local key="$2";
  local value="$3";

  mkdir -p $(dirname ${tofile});
  touch ${tofile};

  sed -i "/^${key}=/d" ${tofile};
  echo "${key}=${value}" >> ${tofile};
}

isValueInList() {
  local list="$1";
  local value="$2";

  echo "${list}" | grep -E -q "^(|.* )${value}(| .*)$"
  return $?;
}

host2ip() {
  getent ahostsv4 "$1" | head -1 | awk '{print $1}'
}

##
## System related
##

# setSettingForSystem <systemname> <key> <value>
setSettingForSystem() {
  local systemname="$1";
  local key="$2";
  local value="$3";

  setValueForKey ${AIMS_VARLIBDIR}/systems/${systemname}.properties "${key}" "${value}"
}

# getSystemForPath <path>
getSystemForPath() {
  local givenpath="$1";

  for systemprop in ${AIMS_VARLIBDIR}/systems/*.properties ; do
    [ ! -f ${systemprop} ] && continue;
    proppath=$(getValueForKey ${systemprop} "path");
    if [ "${proppath}" = "${givenpath}" ] ; then
      getValueForKey ${systemprop} "name";
      return 0;
    fi
  done
}

# registerSystem - Register a system for use on this system
registerSystem() {
  local handlefile="$1";
  local systemname=$(getValueForKey "${handlefile}" "system.name");
  local classname=$(getValueForKey "${handlefile}" "class.name");
  local systemid=$(getValueForKey "${handlefile}" "system.id");
  local pathvalue=$(getValueForKey "${handlefile}" "pathvalue");
  local subpath=$(getValueForKey "${handlefile}" "subpath");
  local description=$(getValueForKey "${handlefile}" "description");

  local registrationcount=0;

  # If a path is given, only search for installations that start on that location.
  for MATCH in $(findfile "${pathvalue}" "${subpath}") ; do
    detectsystem=$(getSystemForPath "${MATCH}")
    if [ -n "${detectsystem}" ] ; then
      echo "Skipping ${MATCH} as it is already registered as \"${detectsystem}\""
      continue;
    fi
    # If systemname (--register-as) and systemid (--system-id) are not set, ask them
    # If both are set, assume that first hit is what the user wants
    if [ -z "${systemname}" ] || [ -z "${systemid}" ] ; then
      printf "Detected ${description} at ${MATCH}. Register? (Y/N) "
      read answer;
      [ "${answer}" != "Y" ] && [ "${answer}" != "y" ] && continue;
      printf "Registering ${MATCH} through which name? [${classname}] "
      read systemname;
      systemname=${systemname:=${classname}};
      printf "Please enter the system id [${classname}] "
      read systemid;
      systemid=${systemid:=${classname}};
      echo "Registering ${MATCH} as \"${systemname}\" with system id \"${systemid}\""
     
      setSettingForSystem "${systemname}" "name" "${systemname}"
      setSettingForSystem "${systemname}" "id" "${systemid}"
      setSettingForSystem "${systemname}" "path" "${MATCH}"

      registrationcount=$((${registrationcount}+1));
      setValueForKey ${handlefile} "registration_${registrationcount}" "${AIMS_VARLIBDIR}/systems/${systemname}.properties"

      # Clear read in data
      answer=""
      systemname=""
      systemid=""
    else
      # We got all information from command line, so continue directly with registering the software
      echo "Detected ${description} at ${MATCH}."
      echo "Registering ${MATCH} as \"${systemname}\" with system id \"${systemid}\""
      
      setSettingForSystem "${systemname}" "name" "${systemname}"
      setSettingForSystem "${systemname}" "id" "${systemid}"
      setSettingForSystem "${systemname}" "path" "${MATCH}"

      registrationcount=1;
      setValueForKey ${handlefile} "registration.${registrationcount}" "${AIMS_VARLIBDIR}/systems/${systemname}.properties"
      break; # Exit after first hit
    fi
  done
  setValueForKey ${handlefile} "registration.count" "${registrationcount}";
}

##
## Service related
##

# setSettingForService <servicename> <key> <value>
setSettingForService() {
  local servicename="$1";
  local key="$2";
  local value="$3";

  setValueForKey ${AIMS_VARLIBDIR}/services/${servicename}.properties "${key}" "${value}"
}

# getSolutionForService <servicename>
getSolutionForService() {
  local servicename="$1";
  local matchname=$(getValueForKey ${AIMS_VARLIBDIR}/services/${servicename}.properties "name");
  if [ "${servicename}" == "${matchname}" ] ; then
    local solutionname=$(getValueForKey ${AIMS_VARLIBDIR}/services/${servicename}.properties "solution.name");
    echo ${solutionname};
  fi
}
# registerService - Register a service on this system
registerService() {
  local handlefile="$1";
  local servicename=$(getValueForKey "${handlefile}" "service.name");
  local dependencies=$(getValueForKey "${handlefile}" "dependencies");
  local solutionname=$(getValueForKey "${handlefile}" "solution.name");
  local serviceid=$(getValueForKey "${handlefile}" "service.id");
  local autoaccept=$(getValueForKey "${handlefile}" "autoaccept");
  local description=$(getValueForKey "${handlefile}" "description");
  local hasmatch=0;
  local answer="";

  # First capture information (if not given)
  if [ -z "${servicename}" ] || [ -z "${serviceid}" ] ; then
    printf "Please enter the service name [${solutionname}] "
    read answer
    servicename="${answer:=${solutionname}}"
    answer=""
    printf "Please enter the service id [${solutionname}] "
    read answer
    serviceid="${answer:=${solutionname}}"
    answer=""
    printf "Give an (optional) description: "
    read answer
    description="${answer}"
    answer="";
  fi

  if [ -f ${AIMS_VARLIBDIR}/services/${servicename}.properties ] ; then
    if [ ${autoaccept} -eq 0 ] ; then
      printf "Service \"${servicename}\" already exists. Proceed with overwriting? (Y/N) "
      read answer
      if [ "${answer}" != "y" ] && [ "${answer}" != "Y" ] ; then
        return 1; 
      fi
    else
      # Service exists but auto-accept is set.
      echo "Service \"${servicename}\" already exists. Skipping."
      return 1;
    fi
  fi

  # For each dependency, find a match
  for DEP in ${dependencies} ; do
    for FILE in ${AIMS_VARLIBDIR}/systems/${DEP}.properties ; do
      source ${FILE};
      if [ ${autoaccept} -eq 0 ] ; then
        printf "AIMS has \"${name}\" as potential ${DEP} implementation at ${path}.\nUse this for the ${solutionname} service? (Y/N) "
        read answer
      else
        echo "AIMS has \"${name}\" as potential ${DEP} implementation at ${path}."
	echo "This will be used for the ${solutionname} service."
      fi
      if [ "${answer}" = "y" ] || [ "${answer}" = "Y" ] || [ ${autoaccept} -eq 1 ] ; then
        setSettingForService "${servicename}" "system.${DEP}.name" "${name}"
        setSettingForService "${servicename}" "system.${DEP}.id" "${id}"
	setSettingForService "${servicename}" "solution.name" "${solutionname}"
        hasmatch=1;
      fi
      answer="";
    done
    if [ ${hasmatch} -eq 0 ] ; then
      echo "Error: The ${DEP} dependency must have a matching registered system."
      exit 10;
    fi
  done

  # Register remainder of information
  setSettingForService "${servicename}" "name" "${servicename}"
  setSettingForService "${servicename}" "id" "${serviceid}"
  setSettingForService "${servicename}" "description" "${description}"

  setValueForKey "${handlefile}" "registration" "${AIMS_VARLIBDIR}/services/${servicename}.properties"
  echo "Service \"${servicename}\" registered with ID \"${serviceid}\" and description \"${description}\"."
}

##
## Cluster related
##

# setSettingForCluster <servicename> <clustername> <key> <value>
setSettingForCluster() {
  local servicename="$1";
  local clustername="$2";
  local key="$3";
  local value="$4";

  setValueForKey ${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}.properties "${key}" "${value}"
}

# getInstancesForCluster <servicename> <clustername>
getInstancesForCluster() {
  local servicename="$1";
  local clustername="$2";

  for instanceprop in ${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}/instances/*.properties ; do
    [ ! -f ${instanceprop} ] && return; # No instances defined
    instance=$(basename ${instanceprop});
    instance=$(echo ${instance} | sed -e 's:.properties::g');

    printf "${instance} ";
  done
  printf "\n";
}

# getServiceForCluster <clustername>
getServiceForCluster() {
  local clustername="$1";

  for propfile in $(find ${AIMS_VARLIBDIR}/services -type f | grep "/clusters/${clustername}.properties") ; do
    # We have a cluster, read it for the service name
    getValueForKey "${propfile}" "service.name";
  done
}

# registerCluster - Register a local cluster definition
registerCluster() {
  local handlefile="$1";
  local servicename=$(getValueForKey "${handlefile}" "service.name");
  local clustername=$(getValueForKey "${handlefile}" "cluster.name");
  local solutionname=$(getValueForKey "${handlefile}" "solution.name");
  local clusterid=$(getValueForKey "${handlefile}" "cluster.id");
  local clustertype=$(getValueForKey "${handlefile}" "cluster.type");
  local clusterdescription=$(getValueForKey "${handlefile}" "cluster.description");
  local answer=""

  # Capture information if not given
  if [ -z "${clustername}" ] || [ -z "${clusterid}" ] ; then
    printf "Please enter the cluster name [${servicename}] "
    read answer
    clustername="${answer:=${servicename}}"
    answer=""
    printf "Please enter the cluster id [${servicename}] "
    read answer
    clusterid="${answer:=${clustername}}"
    answer=""
    printf "Give an (optional) description: "
    read answer
    clusterdescription="${answer:=${clusterdescription}}"
    answer=""
  fi

  # Register information
  setSettingForCluster "${servicename}" "${clustername}" "name" "${clustername}"
  setSettingForCluster "${servicename}" "${clustername}" "id" "${clusterid}"
  setSettingForCluster "${servicename}" "${clustername}" "service.name" "${servicename}"
  setSettingForCluster "${servicename}" "${clustername}" "solution.name" "${solutionname}"
  setSettingForCluster "${servicename}" "${clustername}" "clustertype" "${clustertype}"
  setSettingForCluster "${servicename}" "${clustername}" "description" "${clusterdescription}"

  # Update handle file for registration script
  setValueForKey "${handlefile}" "registration" "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}.properties"
  echo "Cluster \"${clustername}\" registered for the \"${servicename}\" service with description \"${clusterdescription}\"."
}

##
## Instance related
##

# setSettingForInstance <servicename> <clustername> <instancename> <key> <value>
setSettingForInstance() {
  local servicename="$1";
  local clustername="$2";
  local instancename="$3";
  local key="$4";
  local value="$5";

  setValueForKey "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}/instances/${instancename}.properties" "${key}" "${value}"
}

# createInstance - Register a cluster instance on the system
createInstance() {
  local handlefile="$1";
  local servicename=$(getValueForKey "${handlefile}" "service.name");
  local clustername=$(getValueForKey "${handlefile}" "cluster.name");
  local clustertype=$(getValueForKey "${handlefile}" "cluster.type");
  local solutionname=$(getValueForKey "${handlefile}" "solution.name");
  local instancetype=$(getValueForKey "${handlefile}" "type");
  local instancename=$(getValueForKey "${handlefile}" "name");
  local options=$(getValueForKey "${handlefile}" "options");
  local answer="";

  # Capture information if not given
  if [ -z "${instancename}" ] ; then
    printf "Please enter the instance name [${servicename}] "
    read answer
    instancename="${answer:=${servicename}}";
    answer="";
  fi
  
  # Process additional options (if provided)
  # We do this before the "standard" info so that the 'default' values, defined later, always prevail
  for option in $(echo "${options}" | sed -e 's:,: :g') ; do
    optname=$(echo ${option} | awk -F'=' '{print $1}');
    optvalue=$(echo ${option} | awk -F'=' '{print $2}');
    setSettingForInstance "${servicename}" "${clustername}" "${instancename}" "${optname}" "${optvalue}"
  done

  # Register information
  setSettingForInstance "${servicename}" "${clustername}" "${instancename}" "name" "${instancename}"
  setSettingForInstance "${servicename}" "${clustername}" "${instancename}" "type" "${instancetype}"
  setSettingForInstance "${servicename}" "${clustername}" "${instancename}" "solution.name" "${solutionname}"
  setSettingForInstance "${servicename}" "${clustername}" "${instancename}" "cluster.name" "${clustername}"
  setSettingForInstance "${servicename}" "${clustername}" "${instancename}" "cluster.type" "${clustertype}"
  setSettingForInstance "${servicename}" "${clustername}" "${instancename}" "service.name" "${servicename}"

  setValueForKey "${handlefile}" "registration" "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}/instances/${instancename}.properties"
  echo "Instance \"${instancename}\" registered for the \"${clustername}\" cluster (service \"${servicename}\")."
}

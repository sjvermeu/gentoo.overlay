##
## AIMS helper functions
##

# die <message>
die() {
  echo "!! $*" >&2;
  exit 1;
}

# warn <message>
warn() {
  echo "!? $*" >&2;
}

# error <message>
error() {
  echo "!! $*" >&2;
}

# log <message>
log() {
  if [ -n "${AIMS_DEBUG}" ] && [ "${AIMS_DEBUG}" -gt 0 ] ; then
    echo "LOG: $*" >&2;
  fi
}

# debug <message>
debug() {
  if [ -n "${AIMS_DEBUG}" ] && [ "${AIMS_DEBUG}" -gt 1 ] ; then
    echo "DEBUG: $*" >&2;
  fi
}

# getField <key=val> <delimiter> <fieldnum>
getField() {
  local keyval="$1";
  local delim="$2";
  local field="$3";

  if [ -z "${keyval}" ] || [ -z "${delim}" ] || [ -z "${field}" ] ; then
    error "Keyval (\"${keyval}\"), delimiter (\"${delim}\") or field (\"${field}\") cannot be empty (splitLeft)";
    return 1;
  fi

  echo "${keyval}" | cut -f "${field}" -d "${delim}"
}

# deleteIfExists <file> [NOFAIL]
deleteIfExists() {
  local target="$1";
  local fail="$2";

  debug "[deleteIfExists] target=\"${target}\" fail=\"${fail}\""

  if [ -f "${target}" ] ; then
    if ! rm "${target}"; then
      if [ "${fail}" != "NOFAIL" ] ; then
        die "Failed to remove file ${target}"
      else
        echo "Failed to remove file ${target}"
      fi
    fi
  elif [ -d "${target}" ] && [ ${#target} -gt 7 ] ; then
    # The path length must be at least 7 so we do not accidentally remove system directories
    if ! rm -rf "${target}"; then
      if [ "${fail}" != "NOFAIL" ] ; then
        die "Failed to remove directory ${target}"
      else
        echo "Failed to remove directory ${target}"
      fi
    fi
  else
    return 1;
  fi
}

# selinux_restorecon <path>
selinux_restorecon() {
  
  debug "[selinux_restorecon] args = \"$*\""

  if [ -f /sys/fs/selinux/enforce ] ; then
    restorecon -RF "$@";
  fi
}

# findfile <rootpath> <file>
findfile() {
  local rootpath="$1";
  local file="$2";

  debug "[findfile] rootpath=\"${rootpath}\" file=\"${file}\""

  if [ ! -d "${rootpath}" ] ; then
    error "Root path \"${rootpath}\" does not exist (findfile)";
    return 1;
  fi

  LOCATECMD=$(whereis -b locate | awk '{print $2}');
  FINDCMD=$(whereis -b find | awk '{print $2}');
  if [ -x "${LOCATECMD}" ] ; then
    locate "${file}" | grep -E "${file}$" | grep -E "^${rootpath}"; 
  elif [ -x "${FINDCMD}" ] ; then
    find "${rootpath}" | grep -E "${file}$"
  fi
}

# getValueForKey <file> <key>
# Beware: <key> can be a regular expression!
getValueForKey() {
  local fromfile="$1";
  local key="$2";

  debug "[getValueForKey] fromfile=\"${fromfile}\" key=\"${key}\""

  if [ ! -f "${fromfile}" ] ; then
    error "File \"${fromfile}\" does not exist, so cannot retrieve value for key \"${key}\" (getValueForKey)";
    return 1;
  fi

  grep -E "^${key}=" "${fromfile}" | sed -e 's:^[^=]*=::g' | sed -e 's:^"\(.*\)"$:\1:g';
}

# getTypedValueForKey <file> <subtype> <key> - Return the value of <file>.<subtype> if the value is there, or <file> otherwise
getTypedValueForKey() {
  local fromfile="$1";
  local templatetype="$2";
  local key="$3";

  debug "[getTypedValueForKey] fromfile=\"${fromfile}\" templatetype=\"${templatetype}\" key=\"${key}\""

  if [ ! -f "${fromfile}" ] ; then
    error "File \"${fromfile}\" does not exist (getTypedValueForKey)";
    return 1;
  fi

  if [ -f "${fromfile}.${templatetype}" ] ; then
    # Attempt to get the value from the type template
    retval=$(getValueForKey "${fromfile}.${templatetype}" "${key}");
    if [ -z "${retval}" ] ; then
      # No good value obtained, default to the standard file
      getValueForKey "${fromfile}" "${key}";
    else
      echo "${retval}"
    fi
  else
    getValueForKey "${fromfile}" "${key}";
  fi
}

# setValueForKey <file> <key> <value>
setValueForKey() {
  local tofile="$1";
  local key="$2";
  local value="$3";

  debug "[setValueForKey] tofile=\"${tofile}\" key=\"${key}\" value=\"${value}\""

  if [ -z "${tofile}" ] || [ -z "${key}" ] ; then
    error "Target file (\"${file}\") or key (\"${key}\") cannot be empty (setValueForKey)";
    return 1;
  fi

  mkdir -p "$(dirname "${tofile}")";
  touch "${tofile}";

  sed -i "/^${key}=/d" "${tofile}";
  echo "${key}=${value}" >> "${tofile}";
}

# isValueInList <list> <value>
isValueInList() {
  local list="$1";
  local value="$2";

  if [ -z "${list}" ] ; then
    # Empty list so value is never inside of it
    return 1;
  fi

  if [ -z "${value}" ] ; then
    error "Value (\"${value}\") cannot be empty (isValueInList)";
    return 1;
  fi

  echo "${list}" | grep -E -q "^(|.* )${value}(| .*)$"
  return $?;
}

host2ip() {
  local hostparam="$1";

  debug "[host2ip] hostparam=\"${hostparam}\""

  if [ -z "${hostparam}" ] ; then
    error "Host cannot be empty (host2ip)";
    return 1;
  fi

  getent ahostsv4 "${hostparam}" | head -1 | awk '{print $1}'
}

# substituteParamValueInFile <param> <value> <file>
substituteParamValueInFile() {
  local param="$1";
  local value="$2";
  local tfile="$3";

  debug "[substituteParamValueInFile] param=\"${param}\" value=\"${value}\" tfile=\"${tfile}\""

  if [ ! -f "${tfile}" ] ; then
    error "File \"${tfile}\" does not exist (substituteParamValueInFile)";
    return 1;
  fi

  if [ -z "${param}" ] ; then
    error "Empty parameter name received (value=\"${value}\", file=\"${tfile}\") (substituteParamValueInFile)";
    return 1;
  fi

  sed -i -e "s|${param}|${value}|g" "${tfile}" 
}

# expandIterationsInFile <file> <expandkey> <values>
#   Expands iterations (defined as {{expandkey}} in the file), and prefix any {expandkey with one of the <values>
expandIterationsInFile() {
  local file="${1}";
  local expandkey="${2}";
  local values="${3}";

  debug "[expandIterationsInFile] file=\"${file}\" expandkey=\"${expandkey}\" values=\"${values}\""

  if [ ! -f "${file}" ] ; then
    error "File \"${file}\" does not exist, expandkey=\"${expandkey}\" values=\"${values}\" (expandIterationsInFile)";
    return 1;
  fi

  if [ -z "${expandkey}" ] ; then
    error "Expand key cannot be empty (file=\"${file}\", values=\"${values}\") (expandIterationsInFile)";
    return 2;
  fi

  local tmpfile="";
  tmpfile=$(mktemp);
  local awkfile="";
  awkfile=$(mktemp);

  # Values are generally obtained through the get*ForCluster options, so are sets
  # - In case of instances, this is name|type|host
  # - In case of containers, this is name|type
  # 
  # For regular expansions, we just need name (which is the first value)
  # For some optional expansions, we need the type (which is the second value)

  # Using cat to preserve permissions
  cat "${file}" > "${tmpfile}";

  { 
    echo "BEGIN {";
    # Iterate over the values (which should be names in AIMS)
    i=0;
    for value in ${values} ; do
      local name_value="";
      name_value=$(echo "${value}" | awk 'BEGIN{FS="|"}{print $1}');
      local type_value="";
      type_value=$(echo "${value}" | awk 'BEGIN{FS="|"}{print $2}');
      local host_value="";
      host_value=$(echo "${value}" | awk 'BEGIN{FS="|"}{print $3}');

      if [ -n "${host_value}" ] ; then
        name_value="${name_value}-${host_value}"
      fi

      echo "  names[$i] = \"${name_value}\";";
      if [ -n "${type_value}" ] ; then
        echo "  types[$i] = \"${type_value}\";"
      fi
      i=$((i+1));
    done
    echo "}";
    echo "/{{${expandkey}}}/{repeatname=1;next}";
    echo "/{{\/${expandkey}}}/{repeatname=0;next}";
    # The type-based expansions use the type=<value>?<expandkey> format
    # We need to iterate over the passed on types
    for supported_type in $(echo "${values}" | awk 'BEGIN{ FS="|"; RS=" "} {print $2}' | sort | uniq); do
      echo "/{{type=${supported_type}\?${expandkey}}}/{repeattype_${supported_type}=1;next}";
      echo "/{{\/type=${supported_type}\?${expandkey}}}/{repeattype_${supported_type}=0;next}";
    done
    echo "{if(repeatname){";
    echo "  for(i=0;i<$i;i++){";
    echo "    print gensub(\"{${expandkey}\",\"{\"names[i]\"?${expandkey}\",\"g\");";
    echo "  }";
    # Iterate again
    for supported_type in $(echo "${values}" | awk 'BEGIN{ FS="|"; RS=" "} {print $2}' | sort | uniq); do
      echo "}else if(repeattype_${supported_type}){";
      echo "  for(i=0;i<$i;i++){";
      echo "    if(types[i]==\"${supported_type}\") {print gensub(\"{${expandkey}\",\"{\"names[i]\"?${expandkey}\",\"g\");}";
      echo "  }";
    done
    echo "}else{print}}";
  } > "${awkfile}";

  awk -f "${awkfile}" < "${tmpfile}" > "${file}";

  rm "${tmpfile}";
  rm "${awkfile}";
}

# getComponentGroup <compid> <role>
getComponentGroup() {
  local compid="$1";
  local role="$2";

  debug "[getComponentGroup] compid=\"${compid}\" role=\"${role}\""

  if [ -z "${compid}" ] || [ -z "${role}" ] ; then
    error "Compid (\"${compid}\") and role (\"${role}\") cannot be empty (getComponentGroup)";
    return 1;
  fi

  # Default is nss support
  if [ -z "${AIMS_AUTHZ_METHOD}" ] || [ "${AIMS_AUTHZ_METHOD}" = "nss" ] ; then
    local groupname="";
    groupname=$(echo "${AIMS_AUTHZ_NSS_FORMAT_COMPONENT}" | sed -e "s:{componentid}:${compid}:g" -e "s:{role}:${role}:g");

    echo "${groupname}";
  elif [ "${AIMS_AUTHZ_METHOD}" = "aims" ] ; then
    local groupname="";
    groupname=$(echo "${AIMS_AUTHZ_AIMS_FORMAT_COMPONENT}" | sed -e "s:{componentid}:${compid}:g" -e "s:{role}:${role}:g");

    echo "${groupname}";
  fi
}

# getGroupMembers <groupname>
getGroupMembers() {
  local groupname="$1";

  debug "[getGroupMembers] groupname=\"${groupname}\""

  if [ -z "${groupname}" ] ; then
    error "Group name cannot be empty (getGroupMembers)";
    return 1;
  fi

  if [ -z "${AIMS_AUTHZ_METHOD}" ] || [ "${AIMS_AUTHZ_METHOD}" = "nss" ] ; then
    getent group "${groupname}" | awk -F':' '{print $4}' | tr ',' '\n';
  elif [ "${AIMS_AUTHZ_METHOD}" = "aims" ] ; then
    grep "^${groupname}:" "${AIMS_CONFDIR}/groups.txt" | awk -F':' '{print $2}' | tr ',' '\n';
  fi
}

# getClusterGroup <serviceid> <clusterid> <role>
getClusterGroup() {
  local serviceid="$1";
  local clusterid="$2";
  local role="$3";

  debug "[getClusterGroup] serviceid=\"${serviceid}\" clusterid=\"${clusterid}\" role=\"${role}\""

  if [ -z "${serviceid}" ] || [ -z "${clusterid}" ] || [ -z "${role}" ] ; then
    error "Service id (\"${serviceid}\"), cluster id (\"${clusterid}\") and role (\"${role}\") cannot be empty (getClustergroup)";
    return 1;
  fi

  # Default is nss support
  if [ -z "${AIMS_AUTHZ_METHOD}" ] || [ "${AIMS_AUTHZ_METHOD}" = "nss" ] ; then
    local groupname="";
    groupname=$(echo "${AIMS_AUTHZ_NSS_FORMAT_CLUSTER}" | sed -e "s:{serviceid}:${serviceid}:g" -e "s:{clusterid}:${clusterid}:g" -e "s:{role}:${role}:g");

    echo "${groupname}";
  elif [ "${AIMS_AUTHZ_METHOD}" = "aims" ] ; then
    local groupname="";
    groupname=$(echo "${AIMS_AUTHZ_AIMS_FORMAT_CLUSTER}" | sed -e "s:{serviceid}:${serviceid}:g" -e "s:{clusterid}:${clusterid}:g" -e "s:{role}:${role}:g");

    echo "${groupname}";
  fi
}

# getContainerGroup <componentid> <containerid> <role>
getContainerGroup() {
  local componentid="$1";
  local containerid="$2";
  local role="$3";

  debug "[getContainerGroup] componentid=\"${componentid}\" containerid=\"${containerid}\" role=\"${role}\""

  if [ -z "${componentid}" ] || [ -z "${containerid}" ] || [ -z "${role}" ] ; then
    error "Component id (\"${componentid}\"), container id (\"${containerid}\") or role id (\"${role}\") cannot be empty (getContainerGroup)";
    return 1;
  fi

  # Default is nss support
  if [ -z "${AIMS_AUTHZ_METHOD}" ] || [ "${AIMS_AUTHZ_METHOD}" = "nss" ] ; then
    local groupname="";
    groupname=$(echo "${AIMS_AUTHZ_NSS_FORMAT_CONTAINER}" | sed -e "s:{componentid}:${componentid}:g" -e "s:{containerid}:${containerid}:g" -e "s:{role}:${role}:g");

    echo "${groupname}";
  elif [ "${AIMS_AUTHZ_METHOD}" = "aims" ] ; then
    local groupname="";
    groupname=$(echo "${AIMS_AUTHZ_AIMS_FORMAT_CONTAINER}" | sed -e "s:{componentid}:${componentid}:g" -e "s:{containerid}:${containerid}:g" -e "s:{role}:${role}:g");

    echo "${groupname}";
  fi
}

# membersToAdd <mastergroupfile> <slavegroupfile>
membersToAdd() {
  local masterfile="$1";
  local slavefile="$2";

  debug "[membersToAdd] masterfile=\"${masterfile}\" slavefile=\"${slavefile}\""

  if [ ! -f "${masterfile}" ] ; then
    error "Master file \"${masterfile}\" does not exist (membersToAdd)";
    return 1;
  fi

  if [ ! -f "${slavefile}" ] ; then
    error "Slave file \"${slavefile}\" does not exist (membersToAdd)";
    return 2;
  fi

  diff -u "${slavefile}" "${masterfile}" | grep -v '[-+][-+][-+]' | grep "^+" | sed -e "s:^+::g";
}

# membersToRemove <mastergroupfile> <slavegroupfile>
membersToRemove() {
  local masterfile="$1";
  local slavefile="$2";

  debug "[membersToRemove] masterfile=\"${masterfile}\" slavefile=\"${slavefile}\""

  if [ ! -f "${masterfile}" ] ; then
    error "Master file \"${masterfile}\" does not exist (membersToRemove)";
    return 1;
  fi

  if [ ! -f "${slavefile}" ] ; then
    error "Slave file \"${slavefile}\" does not exist (membersToRemove)";
    return 2;
  fi

  diff -u "${slavefile}" "${masterfile}" | grep -v '[-+][-+][-+]' | grep "^-" | sed -e "s:^-::g";
}

# getHostname - Returns the FQDN (if available) or short (if FQDN fails) hostname
getHostname() {
  local rethostname=""

  debug "[getHostname]"

  if ! rethostname=$(hostname --fqdn 2>/dev/null); then
    rethostname=$(hostname);
  fi

  echo "${rethostname}";
}

# getFQDNHostname [<host>]
getFQDNHostname() {
  local rethostname=""
  local targethost="$1";

  debug "[getFQDNHostname] targethost=\"${targethost}\""

  if [ -z "${targethost}" ] ; then
    targethost=$(getHostname);
  fi

  local ipaddress="";
  ipaddress=$(dig +short "${targethost}");

  debug "[getFQDNHostname]   Resolved IP address \"${ipaddress}\" for host \"${targethost}\""

  rethostname=$(dig +short -x "${ipaddress}" | sed -e 's:\.$::g');

  debug "[getFQDNHostname]   Reverse lookup resulted in \"${rethostname}\""

  echo "${rethostname}";
}

# getShortHostname
getShortHostname() {
  hostname;
}

# systemInitStart <name> <filter>
systemInitStart() {
  systemInitCmd start "$1" "$2";
}

# systemInitRestart <name> <filter>
systemInitRestart() {
  systemInitCmd restart "$1" "$2";
}

# systemInitStop <name> <filter>
systemInitStop() {
  systemInitCmd stop "$1" "$2";
}

# systemInitCmd <cmd> <name> <filter>
systemInitCmd() {
  local syscmd="$1";
  local sysname="$2";
  local sysfilter="$3";

  debug "[systemInitCmd] syscmd=\"${syscmd}\" sysname=\"${sysname}\" sysfilter=\"${sysfilter}\"";

  if [ -z "${syscmd}" ] || [ -z "${sysname}" ] ; then
    error "System command (\"${syscmd}\") or name (\"${sysname}\") cannot be empty (systemInitCmd)";
    return 1;
  fi

  if [ -z "${sysfilter}" ] ; then
    sysfilter="${sysname}";
  fi

  # The sysname is not the full name (unless it was placed by AIMS itself).
  # We need to search for the appropriate name to use.

  if [ -x /sbin/rc-service ] && [ -d /etc/init.d ] ; then
    # Assume we are on Gentoo and/or using OpenRC
    initnames=$(find /etc/init.d -type f -name "*${sysname}*" -exec basename '{}' \; | grep "${sysfilter}");
    initcount=$(echo "${initnames}" | awk '{print NF}');
    if [ "${initcount}" -gt 1 ] ; then
      die "Could not uniquely identify the appropriate service"
    fi
    # initnames should now be OK to use
    echo ">>> rc-service ${initnames} ${syscmd}"
    rc-service "${initnames}" "${syscmd}"
  fi
}

##
## Component related
##

# getSettingForComponent <componentname> <key>
getSettingForComponent() {
  local componentname="$1";
  local key="$2";
  local retval="";

  debug "[getSettingForComponent] componentname=\"${componentname}\" key=\"${key}\"";

  if [ ! -f "${AIMS_VARLIBDIR}/components/${componentname}.properties" ] ; then
    error "Component \"${componentname}\" does not exist (getSettingForComponent)";
    return 1;
  fi

  if [ -z "${key}" ] ; then
    error "Key cannot be empty (component=\"${componentname}\") (getSettingForComponent)";
    return 2;
  fi

  tmpfile=$(mktemp);

  cp "${AIMS_VARLIBDIR}/components/${componentname}.properties" "${tmpfile}";
  substitutecomponentPropertiesInFile "${componentname}" "${tmpfile}";

  retval=$(getValueForKey "${tmpfile}" "${key}");
  echo "${retval}";

  debug "[getSettingForComponent] --> ${retval}"

  rm "${tmpfile}";
}


# setSettingForComponent <componentname> <key> <value>
setSettingForComponent() {
  local componentname="$1";
  local key="$2";
  local value="$3";

  debug "[setSettingForComponent] componentname=\"${componentname}\" key=\"${key}\" value=\"${value}\""

  if [ -z "${key}" ] ; then
    error "Key canot be empty (component=\"${componentname}\") (setSettingForComponent)";
    return 1;
  fi

  mkdir -p "${AIMS_VARLIBDIR}/components";
  setValueForKey "${AIMS_VARLIBDIR}/components/${componentname}.properties" "${key}" "${value}"
}

# getComponentForPath <path>
getComponentForPath() {
  local givenpath="$1";

  debug "[getComponentForPath] givenpath=\"${givenpath}\""

  if [ -z "${givenpath}" ] ; then
    error "Path cannot be empty (getComponentForPath)"
    return 1;
  fi

  for componentprop in "${AIMS_VARLIBDIR}"/components/*.properties ; do
    [ ! -f "${componentprop}" ] && continue;
    proppath=$(getValueForKey "${componentprop}" "component.path");
    if [ "${proppath}" = "${givenpath}" ] ; then
      getValueForKey "${componentprop}" "component.name";
      return 0;
    fi
  done
}

# substituteComponentPropertiesInFile <component> <file>
substituteComponentPropertiesInFile() {
  local componentname="${1}";
  local targetfile="${2}";
  local key="";
  local val="";

  debug "[substituteComponentPropertiesInFile] componentname=\"${componentname}\" targetfile=\"${targetfile}\""

  if [ ! -f "${AIMS_VARLIBDIR}/components/${componentname}.properties" ] ; then
    error "Component \"${componentname}\" does not exist (substituteComponentPropertiesInFile)";
    return 1;
  fi

  if [ ! -f "${targetfile}" ] ; then
    error "Target file \"${targetfile}\" does not exist (componet=\"${componentname}\") (substituteComponentPropertiesInFile)";
    return 2;
  fi

  local ck_pre="0"
  local ck_post="1"

  while [ "${ck_pre}" != "${ck_post}" ] ; do
    ck_pre=$(sha256sum "${targetfile}" | awk '{print $1}');

    while read -r keyval ; do
      key=$(getField "${keyval}" "=" 1);
      val=$(getField "${keyval}" "=" "2-");

      substituteParamValueInFile "{${key}}" "${val}" "${targetfile}"
      # Specific parameter request for this component
      substituteParamValueInFile "{${componentname}?${key}}" "${val}" "${targetfile}"
    done < "${AIMS_VARLIBDIR}/components/${componentname}.properties";

    ck_post=$(sha256sum "${targetfile}" | awk '{print $1}');
  done
}

##
## Solution related
##

# getSettingForSolution <solutionname> <key>
getSettingForSolution() {
  local solutionname="${1}";
  local key="${2}";

  local retval="";

  debug "[getSettingForSolution] solutionname=\"${solutionname}\" key=\"${key}\""

  if [ ! -f "${AIMS_LIBDIR}/solutions/${solutionname}/register" ] ; then
    error "Solution \"${solutionname}\" does not exist (getSettingForSolution)";
    return 1;
  fi

  if [ -z "${key}" ] ; then
    error "Key cannot be empty (solutionname=\"${solutionname}\") (getSettingForSolution)";
    return 1;
  fi

  tmpfile=$(mktemp);

  cp "${AIMS_LIBDIR}/solutions/${solutionname}/register" "${tmpfile}";
  substituteSolutionPropertiesInFile "${solutionname}" "${tmpfile}";

  retval=$(getValueForKey "${tmpfile}" "${key}")
  echo "${retval}";

  debug "[getSettingForSolution] --> ${retval}"

  rm "${tmpfile}";
}

# substituteSolutionPropertiesInFile <solutionname> <file>
substituteSolutionPropertiesInFile() {
  local solutionname="${1}";
  local targetfile="${2}";
  local key="";
  local val="";

  debug "[substituteSolutionPropertiesInFile] solutionname=\"${solutionname}\" targetfile=\"${targetfile}\""

  if [ ! -f "${AIMS_LIBDIR}/solutions/${solutionname}/register" ] ; then
    error "Solution \"${solutionname}\" does not exist (substituteSolutionPropertiesInFile)";
    return 1;
  fi

  if [ ! -f "${targetfile}" ] ; then
    error "Target file \"${targetfile}\" does not exist (solutionname=\"${solutionname}\") (substituteSolutionPropertiesInFile)";
    return 2;
  fi

  local ck_pre="0"
  local ck_post="1"

  while [ "${ck_pre}" != "${ck_post}" ] ; do
    ck_pre=$(sha256sum "${targetfile}" | awk '{print $1}');

    while read -r keyval ; do
      key=$(getField "${keyval}" "=" 1);
      val=$(getField "${keyval}" "=" "2-");

      substituteParamValueInFile "{${key}}" "${val}" "${targetfile}"
      # Specific parameter request for this solution
      substituteParamValueInFile "{${solutionname}?${key}}" "${val}" "${targetfile}"
    done < "${AIMS_LIBDIR}/solutions/${solutionname}/register";

    ck_post=$(sha256sum "${targetfile}" | awk '{print $1}');
  done
}


##
## Service related
##

# getSettingForService <servicename> <key>
getSettingForService() {
  local servicename="$1";
  local key="$2";
  local retval="";

  debug "[getSettingForService] servicename=\"${servicename}\" key=\"${key}\""

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}.properties" ] ; then
    error "Service \"${servicename}\" does not exist (getSettingForService)";
    return 1;
  fi

  if [ -z "${key}" ] ; then
    error "Key cannot be empty (servicename=\"${servicename}\") (getSettingForService)";
    return 2;
  fi

  tmpfile=$(mktemp);

  cp "${AIMS_VARLIBDIR}/services/${servicename}.properties" "${tmpfile}";
  for component in $(getValueForKey "${tmpfile}" "service.dependencies") ; do
    substituteComponentPropertiesInFile "${component}" "${tmpfile}" 
  done

  retval=$(getValueForKey "${tmpfile}" "${key}");
  echo "${retval}";

  debug "[getSettingForService] --> ${retval}";

  rm "${tmpfile}";
}

# setSettingForService <servicename> <key> <value>
setSettingForService() {
  local servicename="$1";
  local key="$2";
  local value="$3";

  debug "[setSettingForService] servicename=\"${servicename}\" key=\"${key}\" value=\"${value}\""

  if [ -z "${servicename}" ] || [ -z "${key}" ] ; then
    error "Service name (\"${servicename}\") or key (\"${key}\") cannot be empty (setSettingForService)";
    return 1;
  fi

  mkdir -p "${AIMS_VARLIBDIR}/services";
  setValueForKey "${AIMS_VARLIBDIR}/services/${servicename}.properties" "${key}" "${value}"
}

# substituteServicePropertiesInFile <service> <file>
substituteServicePropertiesInFile() {
  local servicename="$1";
  local targetfile="$2";
  local key="";
  local val="";

  debug "[substituteServicePropertiesInFile] servicename=\"${servicename}\" targetfile=\"${targetfile}\""

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}.properties" ] ; then
    error "Service \"${servicename}\" does not exist (substituteServicePropertiesInFile)";
    return 1;
  fi

  if [ ! -f "${targetfile}" ] ; then
    error "Target file \"${targetfile}\" does not exist (servicename=\"${servicename}\") (substituteServicePropertiesInFile)";
    return 2;
  fi

  local ck_pre="0"
  local ck_post="1"

  while [ "${ck_pre}" != "${ck_post}" ] ; do
    ck_pre=$(sha256sum "${targetfile}" | awk '{print $1}');

    while read -r keyval ; do
      key=$(getField "${keyval}" "=" 1);
      val=$(getField "${keyval}" "=" "2-");

      substituteParamValueInFile "{${key}}" "${val}" "${targetfile}"
      # Specific parameter request for this service
      substituteParamValueInFile "{${servicename}?${key}}" "${val}" "${targetfile}"
    done < "${AIMS_VARLIBDIR}/services/${servicename}.properties";

    ck_post=$(sha256sum "${targetfile}" | awk '{print $1}');
  done
}

# installSolutionTemplateForService <solutionname> <servicename> <templatefile/dir> <targetfile/dir>
installSolutionTemplateForService() {
  local solutionname="${1}";
  local servicename="${2}";
  local template_filedir="${3}";
  local target_filedir="${4}";

  local filelist="";

  debug "[installSolutionTemplateForService] solution_name=\"${solutionname}\" servicename=\"${servicename}\" template_filedir=\"${template_filedir}\" target_filedir=\"${target_filedir}\""

  if [ ! -f "${AIMS_LIBDIR}/solutions/${solutionname}/register" ] ; then
    error "Solution \"${solutionname}\" does not exist (servicename=\"${servicename}\") (installSolutionTemplateForService)";
    return 1;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}.properties" ] ; then
    error "Service \"${servicename}\" does not exist (solution_name=\"${solutionname}\") (installSolutionTemplateForService)";
    return 2;
  fi

  local full_filedir="${AIMS_LIBDIR}/solutions/${solutionname}/templates/${template_filedir}";
 
  if [ ! -d "${full_filedir}" ] && [ ! -f "${full_filedir}" ] ; then
    error "Template file or directory cannot be found or is not valid: ${full_filedir} (installSolutionTemplateForService)";
    return 3;
  elif [ -d "${full_filedir}" ] ; then
    tmpdir=$(mktemp -d)

    # Recursively copy template to temporary directory
    cp -r "${full_filedir}/." "${tmpdir}";

    # Now substitute template entries
    filelist=$(find "${tmpdir}" -type f);
    for file in ${filelist} ; do
      substituteServicePropertiesInFile "${servicename}" "${file}"
    done

    # Recursively copy to the target location
    cp -r "${tmpdir}/." "${target_filedir}"
    rm -R "${tmpdir}";
  else
    tmpdir=$(mktemp -d)
    
    # Copy file to temporary directory
    cp "${full_filedir}" "${tmpdir}";

    # Now substitute template entries
    substituteServicePropertiesInFile "${servicename}" "${tmpdir}/$(basename "${template_filedir}")"

    # Copy to the target location
    cp "${tmpdir}/$(basename "${template_filedir}")" "${target_filedir}"
    rm -R "${tmpdir}";
  fi
}

##
## Cluster related
##

# getSettingForCluster <servicename> <clustername> <key>
getSettingForCluster() {
  local servicename="$1";
  local clustername="$2";
  local key="$3";
  local retval="";

  debug "[getSettingForCluster] servicename=\"${servicename}\" clustername=\"${clustername}\" key=\"${key}\""

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}.properties" ] ; then
    error "Service \"${servicename}\" does not exist (getSettingForCluster)";
    return 1;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}.properties" ] ; then
    error "Cluster \"${clustername}\" does not exist for service \"${servicename}\" (getSettingForCluster)";
    return 2;
  fi

  if [ -z "${key}" ] ; then
    error "Key cannot be empty (servicename=\"${servicename}\", clustername=\"${clustername}\") (getSettingForCluster)";
    return 3;
  fi

  tmpfile=$(mktemp);

  cp "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}.properties" "${tmpfile}";
  substituteServicePropertiesInFile "${servicename}" "${tmpfile}";
  substituteClusterPropertiesInFile "${servicename}" "${clustername}" "${tmpfile}";

  retval=$(getValueForKey "${tmpfile}" "${key}");
  echo "${retval}";

  debug "[getSettingForCluster] --> ${retval}"

  rm "${tmpfile}";
}

# setSettingForCluster <servicename> <clustername> <key> <value>
setSettingForCluster() {
  local servicename="$1";
  local clustername="$2";
  local key="$3";
  local value="$4";

  debug "[setSettingForCluster] servicename=\"${servicename}\" clustername=\"${clustername}\" key=\"${key}\" value=\"${value}\"";

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}.properties" ] ; then
    error "Service \"${servicename}\" does not exist (setSettingForCluster)";
    return 1;
  fi

  if [ -z "${key}" ] ; then
    error "Key cannot be empty (servicename=\"${servicename}\", clustername=\"${clustername}\") (setSettingForCluster)";
    return 2;
  fi

  if [ -z "${clustername}" ] ; then
    error "Clustername cannot be empty (servicename=\"${servicename}\", key=\"${key}\") (setSettingForCluster)";
    return 3;
  fi
  
  mkdir -p "${AIMS_VARLIBDIR}/services/${servicename}/clusters/";
  setValueForKey "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}.properties" "${key}" "${value}"
}

# getInstancesForCluster <servicename> <clustername> - Returns name|type|host list
getInstancesForCluster() {
  local servicename="$1";
  local clustername="$2";

  debug "[getInstancesForCluster] servicename=\"${servicename}\" clustername=\"${clustername}\""

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}.properties" ] ; then
    error "Service \"${servicename}\" does not exist (clustername=\"${clustername}\") (getInstancesForCluster)";
    return 1;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}.properties" ] ; then
    error "Cluster \"${clustername}\" does not exist (servicename=\"${servicename}\") (getInstancesForCluster)";
    return 2;
  fi

  for instanceprop in "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}/instances/"*.properties ; do
    [ ! -f "${instanceprop}" ] && return; # No instances defined
    local instancename="";
    instancename=$(getValueForKey "${instanceprop}" "instance.name");

    local instancehost="";
    instancehost=$(getValueForKey "${instanceprop}" "instance.host");

    local instancetype="";
    instancetype=$(getValueForKey "${instanceprop}" "instance.type");

    printf "%s|%s|%s " "${instancename}" "${instancetype}" "${instancehost}";
  done
  printf "\n";
}

# getContainersForCluster <servicename> <clustername>
getContainersForCluster() {
  local servicename="$1";
  local clustername="$2";

  debug "[getContainersForCluster] servicename=\"${servicename}\" clustername=\"${clustername}\""

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}.properties" ] ; then
    error "Service \"${servicename}\" does not exist";
    return 1;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}.properties" ] ; then
    error "Cluster \"${clustername}\" does not exist for service \"${servicename}\" (getContainersForCluster)";
    return 2;
  fi

  for containerprop in "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}/containers/"*.properties ; do
    [ ! -f "${containerprop}" ] && return; # No containers defined
    local containername="";
    containername=$(getValueForKey "${containerprop}" "container.name");

    local containertype="";
    containertype=$(getValueForKey "${containerprop}" "container.type");

    printf "%s|%s " "${containername}" "${containertype}";
  done
  printf "\n";
}

# getUniqueServiceForCluster <clustername> <servicename>
getUniqueServiceForCluster() {
  local clustername="$1";
  local servicename="$2";

  debug "[getUniqueServiceForCluster] clustername=\"${clustername}\" servicename=\"${servicename}\""

  # Is the given servicename appropriate? If so, pass it back
  if [ -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}.properties" ] ; then
    echo "${servicename}";
  else
    servicename="";
    servicenames=$(grep -h "service.name" "${AIMS_VARLIBDIR}"/services/*/clusters/"${clustername}.properties");
    for name in ${servicenames} ; do
      if [ -n "${servicename}" ] ; then
        error "Could not find a unique service for cluster \"${clustername}\".";
	return 1;
      fi
      servicename=$(getField "${name}" "=" "2-");
    done
  fi

  if [ -z "${servicename}" ] ; then
    error "Could not find the service for cluster \"${clustername}\".";
    return 2;
  fi

  echo "${servicename}"
}

# copyFileToClusterHosts <servicename> <clustername> <filepath> <description>
copyFileToClusterHosts() {
  local servicename="$1";
  local clustername="$2";
  local targetfile="$3";
  local targetdescription="$4";
  local thishostname="";
  thishostname=$(getHostname);

  debug "[copyFileToClusterHosts] servicename=\"${servicename}\" clustername=\"${clustername}\" targetfile=\"${targetfile}\" targetdescription=\"${targetdescription}\", calculated thishostname=\"${thishostname}\""

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}.properties" ] ; then
    error "Service \"${servicename}\" does not exist (copyFileToClusterHosts)";
    return 1;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}.properties" ] ; then
    error "Cluster \"${clustername}\" does not exist for service \"${servicename}\" (copyFileToClusterHosts)";
    return 2;
  fi

  if [ ! -f "${targetfile}" ] ; then
    error "Target file \"${targetfile}\" does not exist, cannot copy to hosts of cluster \"${clustername}\" in service \"${servicename}\" (copyFileToClusterHosts)";
    return 3;
  fi

  local currenthostlist="";
  currenthostlist=$(getValueForKey "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}.properties" "cluster.hosts");

  for clusteredhost in ${currenthostlist} ; do
    if [ "${clusteredhost}" != "${thishostname}" ] ; then
      printf "Copying %s to host %s... " "${targetdescription}" "${clusteredhost}";
      scp -q "${targetfile}" "${clusteredhost}:${targetfile}"
      printf "done\n"
    fi
  done
}

# runCmdOnClusterHosts <servicename> <cluster> <command>...
runCmdOnClusterHosts() {
  local servicename="$1";
  shift;
  local clustername="$1";
  shift;
  local remotecommand="$*";

  debug "[runCmdOnClusterHosts] servicename=\"${servicename}\" clustername=\"${clustername}\" remotecommand=\"${remotecommand}\""

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}.properties" ] ; then
    error "Service \"${servicename}\" does not exist (runCmdOnClusterHosts)";
    return 1;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}.properties" ] ; then
    error "Cluster \"${clustername}\" does not exist for service \"${servicename}\" (runCmdOnClusterHosts)";
    return 2;
  fi

  if [ -z "${remotecommand}" ] ; then
    error "Remote command cannot be empty (servicename=\"${servicename}\", clustername=\"${clustername}\") (runCmdOnClusterHosts)";
    return 3;
  fi

  local hostlist="";
  hostlist=$(getSettingForCluster "${servicename}" "${clustername}" "cluster.hosts");

  for host in ${hostlist} ; do
    if [ "${host}" != "${thishostname}" ] ; then
      ssh "${host}" "${remotecommand}"; 
    fi
  done
}

# aimsSyncCluster <servicename> <clustername> <reason> <param>
aimsSyncCluster() {
  local servicename="$1";
  local clustername="$2";
  local reason="$3";
  local param="$4";
  local thishostname="";
  thishostname=$(getHostname);

  debug "[aimsSyncCluster] servicename=\"${servicename}\" clustername=\"${clustername}\" reason=\"${reason}\" param=\"${param}\", calculated thishostname=\"${thishostname}\""
 
  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}.properties" ] ; then
    error "Service \"${servicename}\" does not exist (aimsSyncCluster)";
    return 1;
  fi

  clusterfile="${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}.properties"
  if [ ! -f "${clusterfile}" ] ; then
    error "Cluster \"${clustername}\" does not exist for service \"${servicename}\" (aimsSyncCluster)";
    return 2;
  fi

  echo "Synchronizing AIMS cluster \"${clustername}\" data and executing synchronization scripts."

  # Now synchronize the cluster resources, run this on every host part of the cluster

  if [ -x "${AIMS_LIBEXECDIR}/solutions/${solutionname}/presync-cluster" ] ; then
    "${AIMS_LIBEXECDIR}/solutions/${solutionname}/presync-cluster" "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}.properties" "${reason}" "${thishostname}" "${param}";
  fi

  if [ -x "${AIMS_LIBEXECDIR}/solutions/${solutionname}/sync-cluster" ] ; then
    
    currenthostlist=$(getValueForKey "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}.properties" "cluster.hosts");
    for clusteredhost in ${currenthostlist} ; do
      if [ "${clusteredhost}" = "${thishostname}" ] ; then
        debug "[aimsSyncCluster] Running ${solutionname}/sync-cluster \"${clusterfile}\" \"${reason}\" \"${thishostname}\" \"${param}\""
        "${AIMS_LIBEXECDIR}/solutions/${solutionname}/sync-cluster" "${clusterfile}" "${reason}" "${thishostname}" "${param}";
      else
        debug "[aimsSyncCluster] Running ssh ${clusteredhost} AIMS_CONFDIR=... AIMS_LIBDIR=... ${solutionname}/sync-cluster \"${clusterfile}\" \"${reason}\" \"${thishostname}\" \"${param}\""
        ssh "${clusteredhost}" AIMS_CONFDIR="\"${AIMS_CONFDIR}\"" AIMS_LIBDIR="\"${AIMS_LIBDIR}\"" "\"${AIMS_LIBEXECDIR}/solutions/${solutionname}/sync-cluster\"" "\"${clusterfile}\"" "\"${reason}\"" "\"${thishostname}\"" "\"${param}\"";
      fi
    done
  fi

  if [ -x "${AIMS_LIBEXECDIR}/solutions/${solutionname}/postsync-cluster" ] ; then
    debug "[aimsSyncCluster] Running ${solutionname}/postsync-cluster \"${clusterfile}\" \"${reason}\" \"${thishostname}\" \"${param}\""
    "${AIMS_LIBEXECDIR}/solutions/${solutionname}/postsync-cluster" "${clusterfile}" "${reason}" "${thishostname}" "${param}";
  fi
}

# substituteClusterPropertiesInFile <service> <cluster> <file>
substituteClusterPropertiesInFile() {
  local servicename="$1";
  local clustername="$2";
  local targetfile="$3";
  local key="";
  local val="";

  debug "[substituteClusterPropertiesInFile] servicename=\"${servicename}\" clustername=\"${clustername}\" targetfile=\"${targetfile}\""

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}.properties" ] ; then
    error "Service \"${servicename}\" does not exist (substituteClusterPropertiesInFile)";
    return 1;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}.properties" ] ; then
    error "Cluster \"${clustername}\" does not exist for service \"${servicename}\" (substituteClusterPropertiesInFile)";
    return 2;
  fi

  if [ ! -f "${targetfile}" ] ; then
    error "Target file \"${targetfile}\" does not exist (substituteClusterPropertiesInFile)";
    return 3;
  fi

  local ck_pre="0"
  local ck_post="1"

  while [ "${ck_pre}" != "${ck_post}" ] ; do
    ck_pre=$(sha256sum "${targetfile}" | awk '{print $1}');

    while read -r keyval ; do
      key=$(getField "${keyval}" "=" 1);
      val=$(getField "${keyval}" "=" "2-");

      substituteParamValueInFile "{${key}}" "${val}" "${targetfile}"
      # Specific parameter request for this cluster
      substituteParamValueInFile "{${clustername}?${key}}" "${val}" "${targetfile}"
    done < "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}.properties";

    ck_post=$(sha256sum "${targetfile}" | awk '{print $1}');
  done
}

# installSolutionTemplateForCluster <solutionname> <servicename> <clustername> <templatefile/dir> <targetfile/dir>
installSolutionTemplateForCluster() {
  local solutionname="${1}";
  local servicename="${2}";
  local clustername="${3}";
  local template_filedir="${4}";
  local target_filedir="${5}";

  local filelist="";

  debug "[installSolutionTemplateForCluster] solution_name=\"${solutionname}\" service_name=\"${servicename}\" cluster_name=\"${clustername}\" template_filedir=\"${template_filedir}\" target_filedir=\"${target_filedir}\""

  local full_filedir="${AIMS_LIBDIR}/solutions/${solutionname}/templates/${template_filedir}";

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}.properties" ] ; then
    error "Service \"${servicename}\" does not exist (installSolutionTemplateForCluster)";
    return 1;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}.properties" ] ; then
    error "Cluster \"${clustername}\" does not exist for service \"${servicename}\" (installSolutionTemplateForCuster)";
    return 2;
  fi

  if [ ! -d "${full_filedir}" ] && [ ! -f "${full_filedir}" ] ; then
    error "Template file or directory cannot be found or is not valid: ${full_filedir} (installSolutionTemplateForCluster)";
    return 1;
  elif [ -d "${full_filedir}" ] ; then
    tmpdir=$(mktemp -d)

    # Recursively copy template to temporary directory
    cp -r "${full_filedir}/." "${tmpdir}";

    # Now substitute template entries
    filelist=$(find "${tmpdir}" -type f);
    for file in ${filelist} ; do
      # First expand instances and containers
      expandIterationsInFile "${file}" "instance" "$(getInstancesForCluster "${servicename}" "${clustername}")"
      expandIterationsInFile "${file}" "container" "$(getContainersForCluster "${servicename}" "${clustername}")"
      for instance in $(getInstancesForCluster "${servicename}" "${clustername}") ; do
        instancename=$(echo "${instance}" | awk 'BEGIN{FS="|"}{print $1}');
	instancehost=$(echo "${instance}" | awk 'BEGIN{FS="|"}{print $3}');
        substituteInstancePropertiesInFile "${servicename}" "${clustername}" "${instancename}" "${instancehost}" "${file}";
      done
      for containername in $(getContainersForCluster "${servicename}" "${clustername}" | awk 'BEGIN{FS="|"}{print $1}'); do
        substituteContainerPropertiesInFile "${servicename}" "${clustername}" "${containername}" "${file}";
      done
      substituteClusterPropertiesInFile "${servicename}" "${clustername}" "${file}"
      substituteServicePropertiesInFile "${servicename}" "${file}"
    done
    
    # Recursively copy to the target location
    cp -r "${tmpdir}/." "${target_filedir}"
    rm -R "${tmpdir}";
  else
    tmpdir=$(mktemp -d)
    
    # Copy file to temporary directory
    cp "${full_filedir}" "${tmpdir}";

    # First expand instances and containers
    file="${tmpdir}/$(basename "${template_filedir}")";
    expandIterationsInFile "${file}" "instance" "$(getInstancesForCluster "${servicename}" "${clustername}")"
    expandIterationsInFile "${file}" "container" "$(getContainersForCluster "${servicename}" "${clustername}")"
    # Now substitute template entries
    for instance in $(getInstancesForCluster "${servicename}" "${clustername}") ; do
      instancename=$(echo "${instance}" | awk 'BEGIN{FS="|"}{print $1}');
      instancehost=$(echo "${instance}" | awk 'BEGIN{FS="|"}{print $3}');
      substituteInstancePropertiesInFile "${servicename}" "${clustername}" "${instancename}" "${instancehost}" "${file}";
    done
    for containername in $(getContainersForCluster "${servicename}" "${clustername}" | awk 'BEGIN{FS="|"}{print $1}'); do
      substituteContainerPropertiesInFile "${servicename}" "${clustername}" "${containername}" "${file}";
    done
    substituteClusterPropertiesInFile "${servicename}" "${clustername}" "${file}"
    substituteServicePropertiesInFile "${servicename}" "${file}"

    # Copy to the target location
    cp "${tmpdir}/$(basename "${template_filedir}")" "${target_filedir}"
    rm -R "${tmpdir}";
  fi
}

##
## Instance related
##

# getSettingForInstance <servicename> <clustername> <instancename> <instancehost> <key>
getSettingForInstance() {
  local servicename="$1";
  local clustername="$2";
  local instancename="$3";
  local instancehost="$4";
  local key="$5";
  local retval="";
  local tmpfile="";

  debug "[getSettingForInstance] servicename=\"${servicename}\" clustername=\"${clustername}\" instancename=\"${instancename}\" instancehost=\"${instancehost}\" key=\"${key}\"";
 
  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}.properties" ] ; then
    error "Service \"${servicename}\" does not exist (getSettingForInstance)";
    return 1;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}.properties" ] ; then
    error "Cluster \"${clustername}\" does not exist for service \"${servicename}\" (getSettingForInstance)";
    return 2;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}/instances/${instancename}-${instancehost}.properties" ] ; then
    error "Instance \"${instancename}\" on host \"${instancehost}\" not found for cluster \"${clustername}\", service \"${servicename}\" (getSettingForInstance)";
    return 3;
  fi

  if [ -z "${key}" ] ; then
    error "Key cannot be empty (service=\"${servicename}\", cluster=\"${clustername}\", instance=\"${instancename}\", host=\"${instancehost}\") (getSettingForInstance)";
    return 4;
  fi

  tmpfile=$(mktemp);

  cp "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}/instances/${instancename}-${instancehost}.properties" "${tmpfile}";
  substituteServicePropertiesInFile "${servicename}" "${tmpfile}";
  substituteClusterPropertiesInFile "${servicename}" "${clustername}" "${tmpfile}";
  substituteInstancePropertiesInFile "${servicename}" "${clustername}" "${instancename}" "${instancehost}" "${tmpfile}"

  retval=$(getValueForKey "${tmpfile}" "${key}");
  echo "${retval}";

  debug "[getSettingForInstance] --> ${retval}";

  rm "${tmpfile}";
}

# setSettingForInstance <servicename> <clustername> <instancename> <instancehost> <key> <value>
setSettingForInstance() {
  local servicename="$1";
  local clustername="$2";
  local instancename="$3";
  local instancehost="$4";
  local key="$5";
  local value="$6";

  debug "[setSettingForInstance] servicename=\"${servicename}\" clustername=\"${clustername}\" instancename=\"${instancename}\" instancehost=\"${instancehost}\" key=\"${key}\" value=\"${value}\""

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}.properties" ] ; then
    error "Service \"${servicename}\" does not exist (setSettingForInstance)";
    return 1;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}.properties" ] ; then
    error "Cluster \"${clustername}\" does not exist for service \"${servicename}\" (setSettingForInstance)";
    return 2;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}/instances/${instancename}-${instancehost}.properties" ] ; then
    error "Instance \"${instancename}\" on host \"${instancehost}\" does not exist for cluster \"${clustername}\" in service \"${servicename}\" (setSettingForInstance)";
    return 3;
  fi

  if [ -z "${key}" ] ; then
    error "Key cannot be empty (service=\"${servicename}\", cluster=\"${clustername}\", instance=\"${instancename}\", host=\"${instancehost}\") (setSettingForInstance)";
    return 4;
  fi

  mkdir -p "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}/instances";
  setValueForKey "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}/instances/${instancename}-${instancehost}.properties" "${key}" "${value}"
}

# getUniqueClusterForInstance <instancename> <instancehost> <clustername>
getUniqueClusterForInstance() {
  local instancename="$1";
  local instancehost="$2";
  local clustername="$3";

  debug "[getUniqueClusterForInstance] instancename=\"${instancename}\" instancehost=\"${instancehost}\" clustername=\"${clustername}\""

  # Is the given clustername appropriate? If so, pass it back
  instancelist=$(ls "${AIMS_VARLIBDIR}"/services/*/clusters/"${clustername}/instances/${instancename}-${instancehost}.properties" 2>/dev/null);
  if [ -n "${instancelist}" ] ; then
    echo "${clustername}"
  else
    clustername="";
    # Not appropriate or not passed on, so let's deduce it ourselves
    instancelist=$(find "${AIMS_VARLIBDIR}/services" -type f -name "${instancename}-${instancehost}.properties");
    for instance in ${instancelist} ; do
      if [ -n "${clustername}" ] ; then
        error "Could not deduce a unique cluster for instance \"${instancename}\", host \"${instancehost}\".";
	return;
      fi
      clustername=$(getValueForKey "${instance}" "cluster.name");
    done
  fi

  echo "${clustername}";
}

# substituteInstancePropertiesInFile <service> <cluster> <instancename> <instancehost> <file>
substituteInstancePropertiesInFile() {
  local servicename="$1";
  local clustername="$2";
  local instancename="$3";
  local instancehost="$4";
  local targetfile="$5";
  local key="";
  local val="";

  debug "[substituteInstancePropertiesInFile] servicename=\"${servicename}\" clustername=\"${clustername}\" instancename=\"${instancename}\" instancehost=\"${instancehost}\" targetfile=\"${targetfile}\""

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}.properties" ] ; then
    error "Service \"${servicename}\" does not exist (substituteInstancePropertiesInFile)";
    return 1;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}.properties" ] ; then
    error "Cluster \"${clustername}\" does not exist for service \"${servicename}\" (substituteInstancePropertiesInFile)";
    return 2;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}/instances/${instancename}-${instancehost}.properties" ] ; then
    error "Instance \"${instancename}\" on host \"${instancehost}\" does not exist for cluster \"${clustername}\" in service \"${servicename}\" (substituteInstancePropertiesInFile)";
    return 3;
  fi

  if [ ! -f "${targetfile}" ] ; then
    error "Target file \"${targetfile}\" does not exist (service=\"${servicename}\", cluster=\"${clustername}\", instance=\"${instancename}\", host=\"${instancehost}\") (substituteInstancePropertiesInFile)";
    return 4;
  fi

  local ck_pre="0"
  local ck_post="1"

  while [ "${ck_pre}" != "${ck_post}" ] ; do
    ck_pre=$(sha256sum "${targetfile}" | awk '{print $1}');

    while read -r keyval ; do
      key=$(getField "${keyval}" "=" 1);
      val=$(getField "${keyval}" "=" "2-");

      substituteParamValueInFile "{${key}}" "${val}" "${targetfile}"
      # Specific parameter request for this instance
      substituteParamValueInFile "{${instancename}?${key}}" "${val}" "${targetfile}"
      # Specific parameter request for this instance/host combination
      substituteParamValueInFile "{${instancename}-${instancehost}?${key}}" "${val}" "${targetfile}"
    done < "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}/instances/${instancename}-${instancehost}.properties";

    ck_post=$(sha256sum "${targetfile}" | awk '{print $1}');
  done
}

# installSolutionTemplateForInstance <solutionname> <servicename> <clustername> <instancename> <instancehost> <templatefile/dir> <targetfile/dir>
installSolutionTemplateForInstance() {
  local solutionname="${1}";
  local servicename="${2}";
  local clustername="${3}";
  local instancename="${4}";
  local instancehost="${5}";
  local template_filedir="${5}";
  local target_filedir="${6}";

  local tmpdir="";
  local filelist="";

  debug "[installSolutionTemplateForInstance solution_name=\"${solutionname}\" service_name=\"${servicename}\" cluster_name=\"${clustername}\" instancename=\"${instancename}\" template_filedir=\"${template_filedir}\" target_filedir=\"${target_filedir}\""

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}.properties" ] ; then
    error "Service \"${servicename}\" does not exist (installSolutionTemplateForInstance)";
    return 1;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}.properties" ] ; then
    error "Cluster \"${clustername}\" does not exist for service \"${servicename}\" (installSolutionTemplateForInstance)";
    return 2;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}/instances/${instancename}-${instancehost}.properties" ] ; then
    error "Instance \"${instancename}\" on host \"${instancehost}\" does not exist for cluster \"${clustername}\" in service \"${servicename}\" (installSolutionTemplateForInstance)";
    return 3;
  fi

  local full_filedir="${AIMS_LIBDIR}/solutions/${solutionname}/templates/${template_filedir}";
 
  if [ ! -d "${full_filedir}" ] && [ ! -f "${full_filedir}" ] ; then
    error "Template file or directory cannot be found or is not valid: ${full_filedir} (installSolutionTemplateForInstance)";
    return 4;
  elif [ -d "${full_filedir}" ] ; then
    tmpdir=$(mktemp -d)

    # Recursively copy template to temporary directory
    cp -r "${full_filedir}/." "${tmpdir}";

    # Now substitute template entries
    filelist=$(find "${tmpdir}" -type f);
    for file in ${filelist} ; do
      substituteServicePropertiesInFile "${servicename}" "${file}"
      substituteClusterPropertiesInFile "${servicename}" "${clustername}" "${file}"
      substituteInstancePropertiesInFile "${servicename}" "${clustername}" "${instancename}" "${instancehost}" "${file}"
    done
    
    # Recursively copy to the target location
    cp -r "${tmpdir}/." "${target_filedir}"
    rm -R "${tmpdir}";
  else
    tmpdir=$(mktemp -d)
    
    # Copy file to temporary directory
    cp "${full_filedir}" "${tmpdir}";

    # Now substitute template entries
    substituteServicePropertiesInFile "${servicename}" "${tmpdir}/$(basename "${template_filedir}")"
    substituteClusterPropertiesInFile "${servicename}" "${clustername}" "${tmpdir}/$(basename "${template_filedir}")"
    substituteInstancePropertiesInFile "${servicename}" "${clustername}" "${instancename}" "${instancehost}" "${tmpdir}/$(basename "${template_filedir}")"

    # Copy to the target location
    cp "${tmpdir}/$(basename "${template_filedir}")" "${target_filedir}"
    rm -R "${tmpdir}";
  fi
}

##
## Container related
##

# getSettingForContainer <servicename> <clustername> <containername> <key>
getSettingForContainer() {
  local servicename="$1";
  local clustername="$2";
  local containername="$3";
  local key="$4";
  
  local tmpfile="";

  debug "[getSettingForContainer] servicename=\"${servicename}\" clustername=\"${clustername}\" containername=\"${containername}\" key=\"${key}\"";

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}.properties" ] ; then
    error "Service \"${servicename}\" does not exist (getSettingForContainer)";
    return 1;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}.properties" ] ; then
    error "Cluster \"${clustername}\" does not exist for service \"${servicename}\" (getSettingForContainer)";
    return 2;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}/containers/${containername}.properties" ] ; then
    error "Container \"${containername}\" does not exist for cluster \"${clustername}\" in service \"${servicename}\" (getSettingForContainer)";
    return 3;
  fi

  if [ -z "${key}" ] ; then
    error "Key cannot be empty (service=\"${servicename}\", cluster=\"${clustername}\", container=\"${containername}\") (getSettingForContainer)";
    return 4;
  fi

  tmpfile=$(mktemp);
  cp "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}/containers/${containername}.properties" "${tmpfile}";
  substituteContainerPropertiesInFile "${servicename}" "${clustername}" "${containername}" "${tmpfile}";
  substituteClusterPropertiesInFile "${servicename}" "${clustername}" "${tmpfile}";
  substituteServicePropertiesInFile "${servicename}" "${tmpfile}";

  getValueForKey "${tmpfile}" "${key}"

  rm "${tmpfile}";
}


# setSettingForContainer <servicename> <clustername> <containername> <key> <value>
setSettingForContainer() {
  local servicename="$1";
  local clustername="$2";
  local containername="$3";
  local key="$4";
  local value="$5";

  debug "[setSettingForContainer] servicename=\"${servicename}\" clustername=\"${clustername}\" containername=\"${containername}\" key=\"${key}\" value=\"${value}\", calculated clustername=\"${clustername}\" servicename=\"${servicename}\""

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}.properties" ] ; then
    error "Service \"${servicename}\" does not exist (setSettingForContainer)";
    return 1;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}.properties" ] ; then
    error "Cluster \"${clustername}\" does not exist for service \"${servicename}\" (setSettingForContainer)";
    return 2;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}/containers/${containername}.properties" ] ; then
    error "Container \"${containername}\" does not exist for cluster \"${clustername}\" in service \"${servicename}\" (setSettingForContainer)";
    return 3;
  fi

  if [ -z "${key}" ] ; then
    error "Key cannot be empty (service=\"${servicename}\", cluster=\"${clustername}\", container=\"${containername}\") (setSettingForContainer)";
    return 4;
  fi

  mkdir -p "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}/containers";
  setValueForKey "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}/containers/${containername}.properties" "${key}" "${value}"
}

# getUniqueClusterForContainer <containername> <clustername>
getUniqueClusterForContainer() {
  local containername="$1";
  local clustername="$2";
  local containerlist="";

  debug "[getUniqueClusterForContainer] containername=\"${containername}\" clustername=\"${clustername}\""

  # Is the given clustername appropriate? If so, pass it back
  containerlist=$(ls "${AIMS_VARLIBDIR}"/services/*/clusters/"${clustername}/containers/${containername}.properties" 2>/dev/null);
  if [ -n "${containerlist}" ] ; then
    echo "${clustername}"
  else
    clustername="";
    # Not appropriate or not passed on, so let's deduce it ourselves
    containerlist=$(find "${AIMS_VARLIBDIR}/services" -type f -name "${containername}.properties" | grep "containers/${containername}.properties");
    for container in ${containerlist} ; do
      if [ -n "${clustername}" ] ; then
        error "Could not deduce a unique cluster for container \"${containername}\"."
	return;
      fi
      clustername=$(getValueForKey "${container}" "cluster.name");
    done
  fi

  echo "${clustername}";
}

# substituteContainerPropertiesInFile <service> <cluster> <container> <file>
substituteContainerPropertiesInFile() {
  local servicename="$1";
  local clustername="$2";
  local containername="$3";
  local targetfile="$4";
  local key="";
  local val="";

  debug "[substituteContainerPropertiesInFile] servicename=\"${servicename}\" clustername=\"${clustername}\" containername=\"${containername}\" targetfile=\"${targetfile}\""

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}.properties" ] ; then
    error "Service \"${servicename}\" does not exist (substituteContainerPropertiesInFile)";
    return 1;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}.properties" ] ; then
    error "Cluster \"${clustername}\" does not exist for service \"${servicename}\" (substituteContainerPropertiesInFile)";
    return 2;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}/containers/${containername}.properties" ] ; then
    error "Container \"${containername}\" does not exist for cluster \"${clustername}\" in service \"${servicename}\" (substituteContainerPropertiesInFile)";
    return 3;
  fi

  if [ ! -f "${targetfile}" ] ; then
    error "Target file \"${targetfile}\" does not exist (service=\"${servicename}\", cluster=\"${clustername}\", container=\"${containername}\") (substituteContainerPropertiesInFile)";
    return 4;
  fi

  local ck_pre="0"
  local ck_post="1"

  while [ "${ck_pre}" != "${ck_post}" ] ; do
    ck_pre=$(sha256sum "${targetfile}" | awk '{print $1}');

    while read -r keyval ; do
      key=$(getField "${keyval}" "=" 1);
      val=$(getField "${keyval}" "=" "2-");

      substituteParamValueInFile "{${key}}" "${val}" "${targetfile}"
      # Specific parameter request for this container
      substituteParamValueInFile "{${containername}?${key}}" "${val}" "${targetfile}"
    done < "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}/containers/${containername}.properties";

    ck_post=$(sha256sum "${targetfile}" | awk '{print $1}');
  done
}

# installSolutionTemplateForContainer <solutionname> <servicename> <clustername> <containername> <templatefile/dir> <targetfile/dir>
installSolutionTemplateForContainer() {
  local solutionname="${1}";
  local servicename="${2}";
  local clustername="${3}";
  local containername="${4}";
  local template_filedir="${5}";
  local target_filedir="${6}";

  local tmpdir="";
  local filelist="";

  debug "[installSolutionTemplateForContainer] solution_name=\"${solutionname}\" service_name=\"${servicename}\" cluster_name=\"${clustername}\" containername=\"${containername}\" template_filedir=\"${template_filedir}\" target_filedir=\"${target_filedir}\""

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}.properties" ] ; then
    error "Service \"${servicename}\" does not exist (installSolutionTemplateForContainer)";
    return 1;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}.properties" ] ; then
    error "Cluster \"${clustername}\" does not exist for service \"${servicename}\" (installSolutionTemplateForContainer)";
    return 2;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}/containers/${containername}.properties" ] ; then
    error "Container \"${containername}\" does not exist for cluster \"${clustername}\" in service \"${servicename}\" (installSolutionTemplateForContainer)";
    return 3;
  fi

  local full_filedir="${AIMS_LIBDIR}/solutions/${solutionname}/templates/${template_filedir}";
 
  if [ ! -d "${full_filedir}" ] && [ ! -f "${full_filedir}" ] ; then
    error "Template file or directory cannot be found or is not valid: ${full_filedir}";
    return 4;
  elif [ -d "${full_filedir}" ] ; then
    tmpdir=$(mktemp -d)

    # Recursively copy template to temporary directory
    cp -r "${full_filedir}/." "${tmpdir}";

    # Now substitute template entries
    filelist=$(find "${tmpdir}" -type f);
    for file in ${filelist} ; do
      substituteServicePropertiesInFile "${servicename}" "${file}"
      substituteClusterPropertiesInFile "${servicename}" "${clustername}" "${file}"
      substituteContainerPropertiesInFile "${servicename}" "${clustername}" "${containername}" "${file}"
    done

    # Recursively copy to the target location
    cp -r "${tmpdir}/." "${target_filedir}"
    rm -R "${tmpdir}";
  else
    tmpdir=$(mktemp -d)
    
    # Copy file to temporary directory
    cp "${full_filedir}" "${tmpdir}";

    # Now substitute template entries
    substituteServicePropertiesInFile "${servicename}" "${tmpdir}/$(basename "${template_filedir}")"
    substituteClusterPropertiesInFile "${servicename}" "${clustername}" "${tmpdir}/$(basename "${template_filedir}")"
    substituteContainerPropertiesInFile "${servicename}" "${clustername}" "${instancename}" "${tmpdir}/$(basename "${template_filedir}")"

    # Copy to the target location
    cp "${tmpdir}/$(basename "${template_filedir}")" "${target_filedir}"
    rm -R "${tmpdir}";
  fi
}

##
## Resource related
##

# getSettingForResource <servicename> <clustername> <instancename> <instancehost> <resourcename> <key>
getSettingForResource() {
  local servicename="$1";
  local clustername="$2";
  local instancename="$3";
  local instancehost="$4";
  local resourcename="$5";
  local key="$6";

  local retval="";
  local tmpfile="";

  debug "[getSettingForResource] servicename=\"${servicename}\" clustername=\"${clustername}\" instancename=\"${instancename}\" instancehost=\"${instancehost}\" resourcename=\"${resourcename}\" key=\"${key}\""

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}.properties" ] ; then
    error "Service \"${servicename}\" does not exist (getSettingForResource)";
    return 1;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}.properties" ] ; then
    error "Cluster \"${clustername}\" does not exist for service \"${servicename}\" (getSettingForResource)";
    return 2;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}/instances/${instancename}-${instancehost}.properties" ] ; then
    error "Instance \"${instancename}\" on host \"${instancehost}\" does not exist for cluster \"${clustername}\" in service \"${servicename}\" (getSettingForResource)";
    return 3;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}/instances/${instancename}-${instancehost}/resources/${resourcename}.properties" ] ; then
    error "Resource \"${resourcename}\" does not exist for instance \"${instancename}\" on host \"${instancehost}\" in cluster \"${clustername}\" of service \"${servicename}\" (getSettingForResource)";
    return 4;
  fi

  if [ -z "${key}" ] ; then
    error "Key cannot be empty (resource=\"${resourcename}\", instance=\"${instancename}\", host=\"${instancehost}\", cluster=\"${clustername}\", service=\"${servicename}\") (getSettingForResource)";
    return 5;
  fi

  tmpfile=$(mktemp);

  cp "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}/instances/${instancename}-${instancehost}/resources/${resourcename}.properties" "${tmpfile}";
  substituteResourcePropertiesInFile "${servicename}" "${clustername}" "${instancename}" "${resourcename}" "${tmpfile}";
  substituteInstancePropertiesInFile "${servicename}" "${clustername}" "${instancename}" "${instancehost}" "${tmpfile}";
  substituteClusterPropertiesInFile "${servicename}" "${clustername}" "${tmpfile}";
  substituteServicePropertiesInFile "${servicename}" "${tmpfile}";

  retval=$(getValueForKey "${tmpfile}" "${key}");
  echo "${retval}";

  debug "[getSettingForResource] --> ${retval}";

  rm "${tmpfile}";
}

# setSettingForResource <servicename> <clustername> <instancename> <instancehost> <resourcename> <key> <value>
setSettingForResource() {
  local servicename="$1";
  local clustername="$2";
  local instancename="$3";
  local instancehost="$4";
  local resourcename="$5";
  local key="$6";
  local value="$7";

  debug "[setSettingForResource] servicename=\"${servicename}\" clustername=\"${clustername}\" instancename=\"${instancename}\" instancehost=\"${instancehost}\" resourcename=\"${resourcename}\" key=\"${key}\" value=\"${value}\""

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}.properties" ] ; then
    error "Service \"${servicename}\" does not exist (setSettingForResource)";
    return 1;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}.properties" ] ; then
    error "Cluster \"${clustername}\" does not exist for service \"${servicename}\" (setSettingForResource)";
    return 2;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}/instances/${instancename}-${instancehost}.properties" ] ; then
    error "Instance \"${instancename}\" on host \"${instancehost}\" does not exist for cluster \"${clustername}\" in service \"${servicename}\" (setSettingForResource)";
    return 3;
  fi

  if [ -z "${resourcename}" ] ; then
    error "Resource name cannot be empty (service=\"${servicename}\", cluster=\"${clustername}\", instance=\"${instancename}\", host=\"${instancehost}\") (setSettingForResource)";
    return 4;
  fi

  if [ -z "${key}" ] ; then
    error "Key cannot be empty (resource=\"${resourcename}\", instance=\"${instancename}\", host=\"${instancehost}\", cluster=\"${clustername}\", service=\"${servicename}\") (setSettingForResource)";
    return 5;
  fi

  mkdir -p "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}/instances/${instancename}-${instancehost}/resources/${resourcename}";
  setValueForKey "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}/instances/${instancename}-${instancehost}/resources/${resourcename}.properties" "${key}" "${value}"
}

# getUniqueInstanceForResource <resourcename> <instancename> <instancehost>
getUniqueInstanceForResource() {
  local resourcename="$1";
  local instancename="$2";
  local instancehost="$3";

  local resourcelist="";

  debug "[getUniqueInstanceForResource] resourcename=\"${resourcename}\" instancename=\"${instancename}\" instancehost=\"${instancehost}\""

  if [ -z "${resourcename}" ] || [ -z "${instancename}" ] || [ -z "${instancehost}" ] ; then
    error "Resource name (\"${resourcename}\"), instance (\"${instancename}\") or host (\"${instancehost}\") cannot be empty (getUniqueInstanceForResource)";
    return 1;
  fi

  # Check if the passed instancename is accurate for the resourcename and host
  resourcelist=$(find "${AIMS_VARLIBDIR}/services" -type "${resourcename}.properties" | grep "instances/${instancename}-${instancehost}/resources/${resourcename}.properties");
  if [ -n "${resourcelist}" ] ; then
    echo "${instancename}";
    return;
  fi
  
  # No hit, let's find the appropriate instance then
  instancename="";
  resourcelist=$(find "${AIMS_VARLIBDIR}/services" -type "${resourcename}.properties" | grep -E "instances/*-${instancehost}/resources/${resourcename}.properties");
  for resource in ${resourcelist} ; do
    if [ -n "${instancename}" ] ; then
      error "Could not uniquely identify instance name for resource \"${resourcename}\"."
      return;
    fi
    instancename=$(getValueForKey "instance.name" "${resource}");
  done

  if [ -z "${instancename}" ] ; then
    error "Could not find instance for resource \"${resourcename}\"."
  fi

  echo "${instancename}";
}

# substituteResourcePropertiesInFile <service> <cluster> <instancename> <instancehost> <resource> <file>
substituteResourcePropertiesInFile() {
  local servicename="$1";
  local clustername="$2";
  local instancename="$3";
  local instancehost="$4";
  local resourcename="$5";
  local targetfile="$6";
  local key="";
  local val="";

  debug "[substituteResourcePropertiesInFile] servicename=\"${servicename}\" clustername=\"${clustername}\" instancename=\"${instancename}\" instancehost=\"${instancehost}\" resourcename=\"${resourcename}\" targetfile=\"${targetfile}\""

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}.properties" ] ; then
    error "Service \"${servicename}\" does not exist (substituteResourcePropertiesInFile)";
    return 1;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}.properties" ] ; then
    error "Cluster \"${clustername}\" does not exist for service \"${servicename}\" (substituteResourcePropertiesInFile)";
    return 2;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}/instances/${instancename}-${instancehost}.properties" ] ; then
    error "Instance \"${instancename}\" on host \"${instancehost}\" does not exist for cluster \"${clustername}\" in service \"${servicename}\" (substituteResourcePropertiesInFile)";
    return 3;
  fi

  if [ ! -f "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}/instances/${instancename}-${instancehost}/resources/${resourcename}.properties" ] ; then
    error "Resource \"${resourcename}\" does not exist for instance \"${instancename}\", host \"${instancehost}\" in cluster \"${clustername}\" of service \"${servicename}\" (substituteResourcePropertiesInFile)";
    return 4;
  fi

  if [ ! -f "${targetfile}" ] ; then
    error "Target file \"${targetfile}\" does not exist (resource=\"${resourcename}\", instance=\"${instancename}\", host=\"${instancehost}\", cluster=\"${clustername}\", service=\"${servicename}\" (substituteResourcePropertiesInFile)";
    return 5;
  fi

  local ck_pre="0"
  local ck_post="1"

  while [ "${ck_pre}" != "${ck_post}" ] ; do
    ck_pre=$(sha256sum "${targetfile}" | awk '{print $1}');

    while read -r keyval ; do
      key=$(getField "${keyval}" "=" 1);
      val=$(getField "${keyval}" "=" "2-");

      substituteParamValueInFile "{${key}}" "${val}" "${targetfile}"
      # Specific parameter request for this resource
      substituteParamValueInFile "{${resourcename}?${key}}" "${val}" "${targetfile}"
    done < "${AIMS_VARLIBDIR}/services/${servicename}/clusters/${clustername}/instances/${instancename}-${instancehost}/resources/${resourcename}.properties";

    ck_post=$(sha256sum "${targetfile}" | awk '{print $1}');
  done
}


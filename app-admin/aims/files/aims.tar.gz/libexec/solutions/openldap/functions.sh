# Helper functions for OpenLDAP

openldapGenerateConfig() {
  local instance_configdir="$1";

  # Generate the aims-slapd-include.conf file
  deleteIfExists "${instance_configdir}/aims-slapd-include.conf"
  for ifile in ${instance_configdir}/aims/*.conf ; do
    test -f ${ifile} || continue;
    echo "include ${ifile}" >> ${instance_configdir}/aims-slapd-include.conf;
  done
}

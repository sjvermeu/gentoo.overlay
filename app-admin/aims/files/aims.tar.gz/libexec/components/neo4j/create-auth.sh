#!/bin/bash

DEFAULT_IFS="$IFS"
SALT_LEN=32

if [ $# -ne 2 ] ; then
  echo "Usage: $0 <username> <password>"
  echo "";
  echo "To create an authentication without password change, remove \"password_change_required\" after the final colon."
  echo "";
  echo "This tool generates an authentication string to be added to the dbms/auth file of Neo4J"
  exit 1;
fi

UNAME="$1";
PASS="$2";

# representing the password in hex format like \xAB\x0C etc
HEX_PASS=$(echo -n $PASS | hexdump -v -e '"\\\x" 1/1 "%02X"')

# create the salt and store it in hex format
SALT=$(cat /dev/urandom | tr -dc 'a-f0-9' | fold -w $SALT_LEN | head -n 1)

HEX_SALT=$(echo -n $SALT | sed -r 's/(.{2})/\\x\1/g')

# calculate the sha256 sum of the salt and password value
# need to split the output because the output ends with a hyphen
IFS=' '

read -a PASSWORD_HASH_ARRAY <<< $(printf $HEX_SALT$HEX_PASS | sha256sum)

PASSWORD_HASH="${PASSWORD_HASH_ARRAY[0]}"

COMBINED=$(echo -n "$PASSWORD_HASH,${SALT}" | awk '{print toupper($1);}')

echo "$UNAME:SHA-256,$COMBINED:password_change_required"

